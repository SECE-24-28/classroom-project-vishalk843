# MockAPI Setup Guide

Follow these steps to connect QuickTopUp to MockAPI for cloud data storage.

## Step 1: Create MockAPI Account

1. Go to https://mockapi.io
2. Sign up for a free account
3. Create a new project

## Step 2: Create Resources

Create two resources in your MockAPI project:

### Resource 1: `plans`
- **Name**: plans
- **Fields**:
  - `title` (string)
  - `amount` (number)
  - `validity` (string)
  - `description` (string)

### Resource 2: `recharges`
- **Name**: recharges
- **Fields**:
  - `employeeId` (string)
  - `employee` (string)
  - `planId` (string)
  - `mobile` (string)
  - `amount` (number)
  - `status` (string)
  - `date` (string)

## Step 3: Get Your API URL

After creating resources, copy your MockAPI root URL. It should look like:
```
https://[your-project-id].mockapi.io/api
```

## Step 4: Update Configuration

1. Open `src/api/api.js`
2. Replace the `ROOT` constant with your MockAPI URL:
   ```javascript
   const ROOT = 'https://[your-project-id].mockapi.io/api';
   ```
3. Set `USE_FALLBACK = false` to enable MockAPI

## Step 5: Populate Sample Data (Optional)

Run the setup script to add sample data:

```bash
node setup-mockapi.js
```

Or manually add data through MockAPI dashboard.

## Step 6: Test Connection

1. Start the development server:
   ```bash
   npm run dev
   ```
2. Try creating a new plan as admin
3. Check if data persists after page refresh
4. Verify data appears in MockAPI dashboard

## Troubleshooting

### Common Issues:

1. **404 Errors**: Check if resource names are exactly `plans` and `recharges`
2. **CORS Errors**: MockAPI should handle CORS automatically
3. **Network Errors**: Check your internet connection and MockAPI URL

### Fallback Mode:

If MockAPI isn't working, you can switch back to localStorage:
1. Set `USE_FALLBACK = true` in `src/api/api.js`
2. Data will be stored locally in browser

## API Endpoints

Once configured, your app will use these endpoints:

- `GET /plans` - Fetch all plans
- `POST /plans` - Create new plan
- `PUT /plans/:id` - Update plan
- `DELETE /plans/:id` - Delete plan
- `GET /recharges` - Fetch all recharges
- `POST /recharges` - Create new recharge

## Features with MockAPI

✅ Real-time data synchronization
✅ Data persistence across devices
✅ Shared data between admin and employees
✅ Automatic ID generation
✅ RESTful API operations
✅ JSON data format