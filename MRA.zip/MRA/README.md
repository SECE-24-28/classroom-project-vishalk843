# QuickTopUp - Mobile Recharge Management System

A modern, responsive mobile recharge management system built with Vite + React + Tailwind CSS. Features admin and employee roles with complete CRUD operations for plans and recharge history tracking.

## ✨ Features

### 🔐 Authentication
- Admin and Employee login systems
- Role-based access control
- Persistent login sessions

### 📱 Plan Management (Admin)
- Create new recharge plans
- Edit existing plans
- Delete plans with confirmation
- View all plans with details

### 💳 Recharge Operations
- Mobile number validation
- Plan selection and recharge processing
- Success confirmation page
- Real-time recharge processing

### 📊 History & Analytics
- Complete recharge history tracking
- Search by mobile number, employee, or plan ID
- Filter by status (success/failed/pending)
- Admin can view all recharges
- Employees can view their own recharges
- Export-ready data format

### 🎨 UI/UX
- Modern dark theme design
- Fully responsive layout
- Toast notifications for user feedback
- Loading states and error handling
- Intuitive navigation

## 🚀 Quick Start

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start development server:**
   ```bash
   npm run dev
   ```

3. **Open your browser:**
   Navigate to `http://localhost:3000`

## 🔑 Demo Credentials

- **Admin:** username=`admin` password=`admin123`
- **Employee:** username=`employee` password=`emp123`

## 🗄️ Data Storage

The app uses localStorage as fallback storage and comes pre-loaded with sample data:
- 3 sample recharge plans
- 3 sample recharge transactions
- All data persists between sessions

## 🔧 MockAPI Integration (Optional)

For production use, you can integrate with MockAPI:

1. Create account at https://mockapi.io
2. Create resources: `plans` and `recharges`
3. Update `src/api/api.js` with your MockAPI URL
4. Set `USE_FALLBACK = false` in the API file

## 📱 Pages & Navigation

- **Landing Page** - Welcome screen with login options
- **Plans** - Browse available recharge plans
- **Recharge** - Process mobile recharges
- **History** - View recharge history with search/filter
- **Admin Dashboard** - Manage plans and view all data
- **Employee Dashboard** - Quick access to plans and personal history
- **Success** - Recharge confirmation page