/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        neon: '#7C3AED',
        neon2: '#06B6D4',
      },
      boxShadow: {
        'neon-sm': '0 6px 20px rgba(124,58,237,0.12)',
      }
    },
  },
  plugins: [],
}
