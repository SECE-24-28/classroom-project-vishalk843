// MockAPI Setup Script
// Run this script to populate your MockAPI with sample data

const axios = require('axios');

// Replace with your MockAPI URL
const MOCKAPI_URL = 'https://674b8b8671933a4e885439b8.mockapi.io/api';

const samplePlans = [
  {
    title: 'Basic Plan',
    amount: 99,
    validity: '28 days',
    description: 'Unlimited calls + 1GB data per day'
  },
  {
    title: 'Standard Plan',
    amount: 199,
    validity: '28 days',
    description: 'Unlimited calls + 2GB data per day'
  },
  {
    title: 'Premium Plan',
    amount: 399,
    validity: '84 days',
    description: 'Unlimited calls + 6GB data per day'
  },
  {
    title: 'Super Saver',
    amount: 149,
    validity: '28 days',
    description: 'Unlimited calls + 1.5GB data per day'
  },
  {
    title: 'Data Booster',
    amount: 299,
    validity: '28 days',
    description: 'Unlimited calls + 3GB data per day'
  }
];

const sampleRecharges = [
  {
    employeeId: 'emp1',
    employee: 'Employee One',
    planId: '1',
    mobile: '9876543210',
    amount: 99,
    status: 'success',
    date: new Date(Date.now() - 86400000).toISOString()
  },
  {
    employeeId: 'admin1',
    employee: 'Admin User',
    planId: '2',
    mobile: '9876543211',
    amount: 199,
    status: 'success',
    date: new Date(Date.now() - 172800000).toISOString()
  },
  {
    employeeId: 'emp1',
    employee: 'Employee One',
    planId: '3',
    mobile: '9876543212',
    amount: 399,
    status: 'success',
    date: new Date(Date.now() - 259200000).toISOString()
  }
];

async function setupMockAPI() {
  try {
    console.log('🚀 Setting up MockAPI with sample data...');
    
    // Add sample plans
    console.log('📱 Adding sample plans...');
    for (const plan of samplePlans) {
      try {
        const response = await axios.post(`${MOCKAPI_URL}/plans`, plan);
        console.log(`✅ Added plan: ${plan.title} (ID: ${response.data.id})`);
      } catch (error) {
        console.log(`❌ Failed to add plan: ${plan.title}`, error.message);
      }
    }
    
    // Add sample recharges
    console.log('💳 Adding sample recharges...');
    for (const recharge of sampleRecharges) {
      try {
        const response = await axios.post(`${MOCKAPI_URL}/recharges`, recharge);
        console.log(`✅ Added recharge: ${recharge.mobile} (ID: ${response.data.id})`);
      } catch (error) {
        console.log(`❌ Failed to add recharge: ${recharge.mobile}`, error.message);
      }
    }
    
    console.log('🎉 MockAPI setup completed!');
    console.log('📋 Summary:');
    console.log(`   - Plans: ${samplePlans.length} added`);
    console.log(`   - Recharges: ${sampleRecharges.length} added`);
    console.log('');
    console.log('🔧 Next steps:');
    console.log('   1. Update src/api/api.js with your MockAPI URL');
    console.log('   2. Set USE_FALLBACK = false in src/api/api.js');
    console.log('   3. Run npm run dev to start the application');
    
  } catch (error) {
    console.error('❌ Setup failed:', error.message);
    console.log('');
    console.log('🔍 Troubleshooting:');
    console.log('   1. Check if your MockAPI URL is correct');
    console.log('   2. Ensure you have created "plans" and "recharges" resources');
    console.log('   3. Verify your internet connection');
  }
}

// Run the setup
setupMockAPI();