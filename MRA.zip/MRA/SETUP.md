# QuickTopUp Setup Instructions

## Option 1: Use with MockAPI (Recommended for production-like testing)

1. Go to https://mockapi.io and create a free account
2. Create a new project
3. Create two resources:
   - **plans** with fields: title (string), amount (number), validity (string), description (string)
   - **recharges** with fields: employeeId (string), employee (string), planId (string), mobile (string), amount (number), status (string), date (string)
4. Copy your MockAPI root URL (e.g., https://xxxxx.mockapi.io/api)
5. Update `src/api/api.js` - replace the ROOT constant with your URL
6. Set `USE_FALLBACK = false` in `src/api/api.js`

## Option 2: Use with LocalStorage (Current setup - works offline)

The app is currently configured to use localStorage as a fallback when MockAPI is not available. This means:
- All data is stored in your browser's localStorage
- Plans and recharges persist between sessions
- No internet connection required
- Perfect for development and testing

## Running the Application

1. Install dependencies: `npm install`
2. Start development server: `npm run dev`
3. Open http://localhost:3000

## Demo Credentials

- **Admin**: username=admin, password=admin123
- **Employee**: username=employee, password=emp123

## Features Working

✅ Admin Login/Logout
✅ Employee Login/Logout  
✅ View Plans (with sample data)
✅ Create New Plans
✅ Edit Existing Plans
✅ Delete Plans
✅ Mobile Recharge Process
✅ Success Page
✅ Responsive Design
✅ Error Handling
✅ Toast Notifications