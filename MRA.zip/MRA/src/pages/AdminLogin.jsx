import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

// Simple demo credentials are used here; in production use a secure backend.
export default function AdminLogin(){
  const [username,setUsername]=useState('admin')
  const [password,setPassword]=useState('admin123')
  const { login } = useAuth()
  const nav = useNavigate()

  const submit = (e) => {
    e.preventDefault()
    // Demo: accept admin/admin123
    if(username==='admin' && password==='admin123'){
      login({ id: 'admin1', name: 'Admin User', role: 'admin' })
      nav('/admin/dashboard')
    } else alert('Invalid admin credentials')
  }

  return (
    <div className="flex items-center justify-center py-20">
      <form onSubmit={submit} className="bg-[#071226] card w-full max-w-md">
        <h2 className="text-xl font-bold mb-4">Admin Login</h2>
        <input className="w-full p-3 rounded mb-3 bg-transparent border border-gray-700" value={username} onChange={e=>setUsername(e.target.value)} />
        <input type="password" className="w-full p-3 rounded mb-3 bg-transparent border border-gray-700" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="btn-primary w-full">Login</button>
      </form>
    </div>
  )
}
