import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { addRecharge, getPlans } from '../api/api'
import { useAuth } from '../context/AuthContext'
import OperatorLogo from '../components/OperatorLogo'

export default function Recharge(){
  const { id } = useParams()
  const location = useLocation()
  const nav = useNavigate()
  const { user } = useAuth()
  const [plan, setPlan] = useState(location.state || null)
  const [mobile, setMobile] = useState('')
  const [detectedOperator, setDetectedOperator] = useState('')
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState({})
  const [step, setStep] = useState(1) // 1: Mobile Input, 2: Confirmation

  useEffect(() => { 
    if (!plan) { 
      getPlans().then(r => { 
        setPlan(r.data.find(p => p.id === id)) 
      }) 
    } 
  }, [id, plan])

  // Enhanced operator detection
  useEffect(() => {
    if (mobile.length >= 4) {
      const prefix = mobile.substring(0, 4)
      let operator = ''
      
      // More comprehensive operator detection
      const operatorPrefixes = {
        'Airtel': ['9876', '9877', '9878', '9879', '8447', '8448', '8449', '7087', '7088'],
        'Jio': ['8901', '8902', '8903', '8904', '8905', '7977', '7978', '7979', '6299', '6300'],
        'Vi': ['9825', '9826', '9827', '9828', '9829', '7405', '7406', '7407', '8238', '8239'],
        'BSNL': ['9434', '9435', '9436', '9437', '9438', '7005', '7006', '7007', '8131', '8132']
      }
      
      for (const [op, prefixes] of Object.entries(operatorPrefixes)) {
        if (prefixes.some(p => prefix.startsWith(p.substring(0, 3)) || prefix.startsWith(p))) {
          operator = op
          break
        }
      }
      
      setDetectedOperator(operator)
    } else {
      setDetectedOperator('')
    }
  }, [mobile])

  const validateMobile = (number) => {
    const errors = {}
    
    if (!number) {
      errors.mobile = 'Mobile number is required'
    } else if (!/^[6-9]\d{9}$/.test(number)) {
      errors.mobile = 'Enter a valid 10-digit mobile number starting with 6-9'
    } else if (plan?.operator !== 'All' && detectedOperator && detectedOperator !== plan.operator) {
      errors.operator = `This plan is for ${plan.operator} but detected operator is ${detectedOperator}`
    }
    
    return errors
  }

  const handleNext = () => {
    const validationErrors = validateMobile(mobile)
    setErrors(validationErrors)
    
    if (Object.keys(validationErrors).length === 0) {
      setStep(2)
    }
  }

  const handleConfirm = async () => {
    setLoading(true)
    try {
      const payload = { 
        employeeId: user?.id || 'emp-demo', 
        employee: user?.name || 'Demo User', 
        planId: plan.id, 
        planTitle: plan.title,
        mobile, 
        amount: plan.amount, 
        operator: detectedOperator || plan.operator,
        status: 'success', 
        date: new Date().toISOString() 
      }
      
      await addRecharge(payload)
      nav('/success', { state: payload })
    } catch (error) {
      console.error('Recharge error:', error)
      setErrors({ submit: 'Recharge failed. Please try again.' })
    }
    setLoading(false)
  }

  if (!plan) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 spinner mx-auto mb-4"></div>
        <p className="text-gray-300 text-lg">Loading plan details...</p>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#071226] via-[#081425] to-[#0a1628] p-6">
      <div className="max-w-4xl mx-auto">
        {/* Progress Indicator */}
        <div className="card mb-8 animate-slide-left">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
              step >= 1 ? 'bg-gradient-to-r from-neon to-neon2 text-white' : 'bg-gray-700 text-gray-400'
            }`}>
              1
            </div>
            <div className={`h-1 w-20 rounded ${step >= 2 ? 'bg-gradient-to-r from-neon to-neon2' : 'bg-gray-700'}`}></div>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
              step >= 2 ? 'bg-gradient-to-r from-neon to-neon2 text-white' : 'bg-gray-700 text-gray-400'
            }`}>
              2
            </div>
          </div>
          <div className="text-center text-gray-400">
            {step === 1 ? '📱 Enter Mobile Details' : '✅ Confirm Recharge'}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Plan Summary Card */}
          <div className="card animate-slide-left">
            <div className="text-center mb-6">
              <div className="flex justify-center items-center gap-4 mb-6">
                <OperatorLogo operator={plan.operator} size="xl" />
                <div>
                  <div className="text-xs text-gray-400 bg-gray-800/50 px-3 py-1 rounded-full mb-2">
                    {plan.category}
                  </div>
                  <h2 className="text-4xl font-bold text-gradient">{plan.title}</h2>
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-neon/10 to-neon2/10 rounded-3xl p-6 border border-neon/20">
                <div className="text-5xl font-bold text-gradient mb-2">₹{plan.amount}</div>
                <div className="text-gray-400">Valid for {plan.validity}</div>
              </div>
            </div>
            
            {/* Plan Benefits */}
            <div className="bg-gray-800/30 rounded-2xl p-6">
              <h4 className="text-white font-bold mb-4 flex items-center gap-2">
                ✨ Plan Benefits
              </h4>
              <p className="text-gray-300 mb-4">{plan.description}</p>
              {plan.benefits && (
                <div className="space-y-2">
                  {plan.benefits.map((benefit, index) => (
                    <div key={index} className="flex items-center text-sm text-gray-300">
                      <span className="text-green-400 mr-3 text-lg">✓</span>
                      {benefit}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Recharge Form */}
          <div className="card animate-slide-right">
            {step === 1 ? (
              <>
                <h3 className="text-3xl font-bold text-gradient mb-8 text-center">
                  📱 Enter Mobile Number
                </h3>
                
                <div className="space-y-6">
                  {/* Mobile Number Input */}
                  <div>
                    <label className="block text-gray-400 text-sm font-medium mb-3">
                      Mobile Number
                    </label>
                    <div className="relative">
                      <input 
                        type="tel"
                        className={`input-field text-2xl font-mono text-center ${
                          errors.mobile || errors.operator ? 'border-red-500' : ''
                        }`}
                        placeholder="Enter 10-digit number" 
                        value={mobile} 
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '').slice(0, 10)
                          setMobile(value)
                          setErrors({})
                        }}
                        maxLength="10"
                      />
                      <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-2xl">
                        📱
                      </div>
                    </div>
                    
                    {/* Error Messages */}
                    {errors.mobile && (
                      <p className="text-red-400 text-sm mt-2 flex items-center animate-slide-right">
                        <span className="mr-2">⚠️</span> {errors.mobile}
                      </p>
                    )}
                    {errors.operator && (
                      <p className="text-yellow-400 text-sm mt-2 flex items-center animate-slide-right">
                        <span className="mr-2">⚠️</span> {errors.operator}
                      </p>
                    )}
                  </div>

                  {/* Operator Detection */}
                  {detectedOperator && (
                    <div className="bg-gray-800/50 rounded-2xl p-4 animate-slide-right">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-gray-400">Detected Operator:</span>
                          <div className="flex items-center gap-2">
                            <OperatorLogo operator={detectedOperator} size="sm" />
                            <span className="text-white font-semibold">{detectedOperator}</span>
                          </div>
                        </div>
                        {plan.operator !== 'All' && detectedOperator === plan.operator && (
                          <span className="status-success">Compatible</span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Operator Guide */}
                  <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-6">
                    <h5 className="text-blue-400 font-bold mb-4 flex items-center gap-2">
                      📋 Supported Operators
                    </h5>
                    <div className="grid grid-cols-2 gap-4">
                      {['Airtel', 'Jio', 'Vi', 'BSNL'].map(op => (
                        <div key={op} className="flex items-center gap-3">
                          <OperatorLogo operator={op} size="sm" />
                          <span className="text-gray-300">{op}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Next Button */}
                  <button 
                    onClick={handleNext}
                    disabled={!mobile || mobile.length !== 10}
                    className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Continue to Confirmation →
                  </button>
                </div>
              </>
            ) : (
              <>
                <h3 className="text-3xl font-bold text-gradient mb-8 text-center">
                  ✅ Confirm Your Recharge
                </h3>
                
                <div className="space-y-6">
                  {/* Confirmation Details */}
                  <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-2xl p-6">
                    <div className="text-center mb-6">
                      <div className="flex items-center justify-center gap-4 mb-4">
                        <OperatorLogo operator={detectedOperator || plan.operator} size="lg" />
                        <div>
                          <div className="text-3xl font-bold text-gradient">₹{plan.amount}</div>
                          <div className="text-gray-400">Recharge Amount</div>
                        </div>
                      </div>
                      <div className="text-2xl font-bold text-white">{mobile}</div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
                        <span className="text-gray-400">Plan</span>
                        <span className="text-white font-semibold">{plan.title}</span>
                      </div>
                      
                      <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
                        <span className="text-gray-400">Validity</span>
                        <span className="text-white">{plan.validity}</span>
                      </div>
                      
                      <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
                        <span className="text-gray-400">Operator</span>
                        <span className="text-white">{detectedOperator || plan.operator}</span>
                      </div>
                      
                      <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
                        <span className="text-gray-400">Service Charge</span>
                        <span className="text-green-400">FREE</span>
                      </div>
                    </div>
                  </div>

                  {/* Error Message */}
                  {errors.submit && (
                    <p className="text-red-400 text-sm flex items-center animate-slide-right">
                      <span className="mr-2">❌</span> {errors.submit}
                    </p>
                  )}

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 gap-4">
                    <button 
                      onClick={() => setStep(1)}
                      disabled={loading}
                      className="btn-secondary"
                    >
                      ← Back
                    </button>
                    
                    <button 
                      onClick={handleConfirm}
                      disabled={loading}
                      className="btn-success"
                    >
                      {loading ? (
                        <div className="flex items-center justify-center gap-2">
                          <div className="w-4 h-4 spinner"></div>
                          Processing...
                        </div>
                      ) : (
                        '🚀 Confirm Recharge'
                      )}
                    </button>
                  </div>

                  {/* Security Note */}
                  <div className="text-center text-xs text-gray-500 bg-gray-800/30 rounded-xl p-4">
                    🔒 Your transaction is secured with 256-bit encryption
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}