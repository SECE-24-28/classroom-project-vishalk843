import { Link } from 'react-router-dom'
import { useState, useEffect } from 'react'
import OperatorLogo from '../components/OperatorLogo'

export default function Home() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [stats, setStats] = useState({ users: 0, transactions: 0, operators: 0 })

  const slides = [
    {
      title: "Lightning Fast Recharges ⚡",
      subtitle: "Instant mobile top-ups in seconds",
      bg: "from-yellow-100 via-orange-100 to-red-100",
      icon: "⚡"
    },
    {
      title: "Secure & Trusted 🔒",
      subtitle: "Bank-grade security for all transactions",
      bg: "from-green-100 via-blue-100 to-purple-100",
      icon: "🔒"
    },
    {
      title: "All Networks Supported 📡",
      subtitle: "Airtel, Jio, Vi, BSNL & more",
      bg: "from-pink-100 via-purple-100 to-indigo-100",
      icon: "📡"
    }
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [slides.length])

  useEffect(() => {
    // Animate stats
    const animateStats = () => {
      setTimeout(() => setStats({ users: 50000, transactions: 125000, operators: 4 }), 500)
    }
    animateStats()
  }, [])

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section with Carousel */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-gray-50 to-blue-50">
        {/* Animated Background */}
        <div className="absolute inset-0">
          {slides.map((slide, index) => (
            <div
              key={index}
              className={`absolute inset-0 bg-gradient-to-br ${slide.bg} transition-opacity duration-1000 ${
                index === currentSlide ? 'opacity-30' : 'opacity-0'
              }`}
            />
          ))}
        </div>

        {/* Floating Elements */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-purple-400 rounded-full opacity-20 animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${3 + Math.random() * 4}s`
              }}
            />
          ))}
        </div>

        <div className="relative z-10 text-center px-6 max-w-6xl mx-auto">
          <div className="mb-8">
            <div className="text-8xl mb-6 animate-bounce">
              {slides[currentSlide].icon}
            </div>
            <h1 className="text-7xl font-black mb-6 text-gradient animate-glow">
              QuickTopUp
            </h1>
            <div className="h-20 mb-8">
              <h2 className="text-4xl font-bold text-gray-800 animate-slide-right">
                {slides[currentSlide].title}
              </h2>
              <p className="text-xl text-gray-600 mt-2 animate-slide-left">
                {slides[currentSlide].subtitle}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12">
            <Link
              to="/plans"
              className="px-12 py-6 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white text-xl font-bold rounded-full hover:scale-110 transition-all duration-300 shadow-2xl hover:shadow-purple-500/50 animate-pulse"
            >
              🚀 Start Recharging
            </Link>
            <Link
              to="/about"
              className="px-12 py-6 bg-white text-gray-800 text-xl font-bold rounded-full hover:scale-110 transition-all duration-300 shadow-2xl border-2 border-gray-300 hover:border-purple-400"
            >
              📖 Learn More
            </Link>
          </div>

          {/* Slide Indicators */}
          <div className="flex justify-center gap-3">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-4 h-4 rounded-full transition-all ${
                  index === currentSlide ? 'bg-purple-600 scale-125' : 'bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-r from-indigo-50 via-purple-50 to-pink-50">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-5xl font-bold text-center mb-16 text-gradient">
            🌟 Trusted by Millions
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center card bg-accent-blue hover:scale-105 transition-all">
              <div className="text-6xl mb-4 animate-bounce">👥</div>
              <div className="text-5xl font-bold text-blue-600 mb-2">{stats.users.toLocaleString()}+</div>
              <div className="text-xl text-blue-700">Happy Users</div>
            </div>
            <div className="text-center card bg-accent-purple hover:scale-105 transition-all">
              <div className="text-6xl mb-4 animate-pulse">💳</div>
              <div className="text-5xl font-bold text-purple-600 mb-2">{stats.transactions.toLocaleString()}+</div>
              <div className="text-xl text-purple-700">Transactions</div>
            </div>
            <div className="text-center card bg-accent-green hover:scale-105 transition-all">
              <div className="text-6xl mb-4 animate-spin">📡</div>
              <div className="text-5xl font-bold text-green-600 mb-2">{stats.operators}+</div>
              <div className="text-xl text-green-700">Networks</div>
            </div>
          </div>
        </div>
      </section>

      {/* Operators Section */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-5xl font-bold text-center mb-16 text-gradient">
            📱 Supported Networks
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {['Airtel', 'Jio', 'Vi', 'BSNL'].map((operator, index) => (
              <div
                key={operator}
                className="text-center card hover:scale-110 transition-all animate-slide-right"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <OperatorLogo operator={operator} size="xl" />
                <div className="mt-4 text-2xl font-bold text-gray-800">{operator}</div>
                <div className="text-gray-600">Instant Recharge</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-r from-teal-50 via-blue-50 to-indigo-50">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-5xl font-bold text-center mb-16 text-gradient">
            ✨ Why Choose Us?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: '⚡', title: 'Lightning Fast', desc: 'Recharge in under 5 seconds', color: 'bg-accent-yellow' },
              { icon: '🔒', title: 'Bank-Level Security', desc: '256-bit SSL encryption', color: 'bg-accent-green' },
              { icon: '💰', title: 'Best Prices', desc: 'Competitive rates guaranteed', color: 'bg-accent-blue' },
              { icon: '📱', title: 'All Networks', desc: 'Support for every operator', color: 'bg-accent-purple' },
              { icon: '🎯', title: '99.9% Success', desc: 'Highest success rate', color: 'bg-accent-orange' },
              { icon: '🏆', title: 'Award Winning', desc: 'Best recharge app 2024', color: 'bg-accent-purple' }
            ].map((feature, index) => (
              <div
                key={feature.title}
                className={`card ${feature.color} hover:scale-105 transition-all animate-slide-left`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="text-5xl mb-4 animate-float">
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-100/20 to-blue-100/20"></div>
        <div className="relative z-10 max-w-4xl mx-auto text-center px-6">
          <h2 className="text-6xl font-bold mb-8 text-gradient animate-glow">
            Ready to Experience the Future?
          </h2>
          <p className="text-2xl text-gray-700 mb-12">
            Join millions of users who trust QuickTopUp for their mobile recharge needs
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link
              to="/plans"
              className="px-16 py-6 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 text-white text-2xl font-bold rounded-full hover:scale-110 transition-all duration-300 shadow-2xl hover:shadow-purple-500/50 animate-pulse"
            >
              🚀 Get Started Now
            </Link>
            <Link
              to="/services"
              className="px-16 py-6 bg-white text-gray-800 text-2xl font-bold rounded-full hover:scale-110 transition-all duration-300 shadow-2xl border-2 border-gray-300 hover:border-purple-400"
            >
              🛠️ Our Services
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}