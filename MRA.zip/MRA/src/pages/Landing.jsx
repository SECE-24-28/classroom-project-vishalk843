import { Link } from 'react-router-dom';

export default function Landing(){
  return (
    <div className="flex flex-col items-center justify-center text-center py-24 px-4">
      <h1 className="text-5xl font-extrabold text-white">QuickTopUp</h1>
      <p className="text-gray-300 mt-4 max-w-xl">Fast, secure and modern mobile recharge system — Admin & Employee roles, powered by MockAPI.</p>
      <div className="mt-8 flex gap-4">
        <Link to="/admin-login" className="btn-primary">Admin Login</Link>
        <Link to="/employee-login" className="btn-primary">Employee Login</Link>
      </div>
    </div>
  )
}
