import { useState } from 'react'
import { Link } from 'react-router-dom'

export default function Services() {
  const [activeService, setActiveService] = useState(0)

  const services = [
    {
      id: 'mobile-recharge',
      title: 'Mobile Recharge',
      icon: '📱',
      color: 'from-blue-500 to-cyan-500',
      description: 'Instant mobile top-ups for all major operators',
      features: ['Instant Processing', 'All Networks', '24/7 Available', 'Cashback Offers'],
      price: 'Free Service',
      popular: true
    },
    {
      id: 'data-plans',
      title: 'Data Plans',
      icon: '📊',
      color: 'from-purple-500 to-pink-500',
      description: 'High-speed data plans for unlimited browsing',
      features: ['High Speed 4G/5G', 'Flexible Validity', 'No Fair Usage Policy', 'Instant Activation'],
      price: 'Starting ₹99',
      popular: false
    },
    {
      id: 'dth-recharge',
      title: 'DTH Recharge',
      icon: '📺',
      color: 'from-green-500 to-emerald-500',
      description: 'Recharge your DTH connection instantly',
      features: ['All DTH Operators', 'HD Channels', 'Instant Activation', 'Special Packs'],
      price: 'Starting ₹150',
      popular: false
    },
    {
      id: 'bill-payments',
      title: 'Bill Payments',
      icon: '💳',
      color: 'from-orange-500 to-red-500',
      description: 'Pay all your utility bills in one place',
      features: ['Electricity Bills', 'Water Bills', 'Gas Bills', 'Internet Bills'],
      price: 'Free Service',
      popular: false
    },
    {
      id: 'wallet-services',
      title: 'Digital Wallet',
      icon: '💰',
      color: 'from-indigo-500 to-purple-500',
      description: 'Secure digital wallet for all transactions',
      features: ['Instant Transfers', 'QR Payments', 'Cashback Rewards', 'Bank Integration'],
      price: 'Free to Use',
      popular: false
    },
    {
      id: 'api-services',
      title: 'API Services',
      icon: '🔌',
      color: 'from-teal-500 to-blue-500',
      description: 'Integration APIs for businesses',
      features: ['RESTful APIs', 'Real-time Status', 'Webhook Support', '99.9% Uptime'],
      price: 'Custom Pricing',
      popular: false
    }
  ]

  const plans = [
    {
      name: 'Basic',
      price: 'Free',
      color: 'from-gray-600 to-gray-700',
      features: ['5 Recharges/month', 'Basic Support', 'Standard Processing'],
      cta: 'Get Started'
    },
    {
      name: 'Pro',
      price: '₹99/month',
      color: 'from-blue-600 to-purple-600',
      features: ['Unlimited Recharges', 'Priority Support', 'Instant Processing', 'Cashback Rewards'],
      cta: 'Upgrade Now',
      popular: true
    },
    {
      name: 'Business',
      price: '₹499/month',
      color: 'from-purple-600 to-pink-600',
      features: ['API Access', 'Bulk Operations', 'Dedicated Support', 'Custom Integration'],
      cta: 'Contact Sales'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-900 via-pink-900 to-purple-900">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-80 h-80 bg-gradient-to-br from-rose-400/20 to-pink-600/20 rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-gradient-to-br from-purple-400/20 to-indigo-600/20 rounded-full blur-3xl animate-float" style={{animationDelay: '3s'}}></div>
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
          <div className="text-8xl mb-6 animate-bounce">🛠️</div>
          <h1 className="text-7xl font-black mb-6 bg-gradient-to-r from-rose-400 via-pink-400 to-purple-400 bg-clip-text text-transparent animate-glow">
            Our Services
          </h1>
          <p className="text-2xl text-rose-200 max-w-3xl mx-auto leading-relaxed">
            Comprehensive digital solutions for all your mobile and utility needs
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={service.id}
                className={`relative bg-gradient-to-br from-rose-800/40 to-purple-800/40 backdrop-blur-xl rounded-3xl p-8 border border-rose-500/30 hover:scale-105 transition-all cursor-pointer animate-slide-right ${
                  activeService === index ? 'ring-4 ring-pink-400/50' : ''
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
                onClick={() => setActiveService(index)}
              >
                {service.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-4 py-1 rounded-full text-sm font-bold">
                    🔥 Popular
                  </div>
                )}
                
                <div className={`w-20 h-20 rounded-3xl bg-gradient-to-r ${service.color} flex items-center justify-center text-4xl mb-6 animate-float`}>
                  {service.icon}
                </div>
                
                <h3 className="text-2xl font-bold text-rose-300 mb-4">{service.title}</h3>
                <p className="text-rose-100 mb-6">{service.description}</p>
                
                <div className="space-y-2 mb-6">
                  {service.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center text-sm text-rose-200">
                      <span className="text-green-400 mr-2">✓</span>
                      {feature}
                    </div>
                  ))}
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-pink-400">{service.price}</span>
                  <Link
                    to="/plans"
                    className={`px-6 py-3 bg-gradient-to-r ${service.color} text-white rounded-2xl font-bold hover:scale-110 transition-all`}
                  >
                    Get Started
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Service View */}
      <section className="py-20 bg-gradient-to-r from-purple-900/50 to-pink-900/50">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-rose-400 to-pink-400 bg-clip-text text-transparent">
            🔍 Service Spotlight
          </h2>
          
          <div className="bg-gradient-to-br from-rose-800/40 to-purple-800/40 backdrop-blur-xl rounded-3xl p-12 border border-rose-500/30">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className={`w-32 h-32 rounded-3xl bg-gradient-to-r ${services[activeService].color} flex items-center justify-center text-6xl mb-8 animate-float mx-auto lg:mx-0`}>
                  {services[activeService].icon}
                </div>
                <h3 className="text-4xl font-bold text-rose-300 mb-6">{services[activeService].title}</h3>
                <p className="text-xl text-rose-100 mb-8">{services[activeService].description}</p>
                
                <div className="grid grid-cols-2 gap-4">
                  {services[activeService].features.map((feature, idx) => (
                    <div key={idx} className="bg-rose-900/50 rounded-2xl p-4 border border-rose-600/30">
                      <div className="flex items-center text-rose-200">
                        <span className="text-green-400 mr-2 text-xl">✓</span>
                        {feature}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="text-center">
                <div className="bg-gradient-to-br from-rose-900/50 to-purple-900/50 rounded-3xl p-8 border border-rose-600/30">
                  <div className="text-6xl mb-4 animate-pulse">💎</div>
                  <div className="text-4xl font-bold text-pink-400 mb-2">{services[activeService].price}</div>
                  <div className="text-rose-200 mb-6">Starting Price</div>
                  <Link
                    to="/plans"
                    className={`inline-block px-12 py-4 bg-gradient-to-r ${services[activeService].color} text-white rounded-2xl font-bold text-xl hover:scale-110 transition-all`}
                  >
                    Try Now
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Plans */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-rose-400 to-pink-400 bg-clip-text text-transparent">
            💰 Pricing Plans
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <div
                key={plan.name}
                className={`relative bg-gradient-to-br from-rose-800/40 to-purple-800/40 backdrop-blur-xl rounded-3xl p-8 border border-rose-500/30 hover:scale-105 transition-all animate-slide-right ${
                  plan.popular ? 'ring-4 ring-pink-400/50 scale-105' : ''
                }`}
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-6 py-2 rounded-full font-bold">
                    ⭐ Most Popular
                  </div>
                )}
                
                <div className="text-center mb-8">
                  <h3 className="text-3xl font-bold text-rose-300 mb-4">{plan.name}</h3>
                  <div className={`text-5xl font-bold bg-gradient-to-r ${plan.color} bg-clip-text text-transparent mb-2`}>
                    {plan.price}
                  </div>
                </div>
                
                <div className="space-y-4 mb-8">
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center text-rose-200">
                      <span className="text-green-400 mr-3 text-xl">✓</span>
                      {feature}
                    </div>
                  ))}
                </div>
                
                <button className={`w-full py-4 bg-gradient-to-r ${plan.color} text-white rounded-2xl font-bold text-lg hover:scale-105 transition-all`}>
                  {plan.cta}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gradient-to-r from-purple-900/50 to-pink-900/50">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-rose-400 to-pink-400 bg-clip-text text-transparent">
            ❓ Frequently Asked Questions
          </h2>
          
          <div className="space-y-6">
            {[
              { q: 'How fast are the recharges?', a: 'All recharges are processed instantly within 5 seconds.' },
              { q: 'Is my payment information secure?', a: 'Yes, we use bank-grade 256-bit SSL encryption for all transactions.' },
              { q: 'Which operators do you support?', a: 'We support all major operators including Airtel, Jio, Vi, and BSNL.' },
              { q: 'Can I get a refund if recharge fails?', a: 'Yes, failed recharges are automatically refunded within 24 hours.' }
            ].map((faq, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-rose-800/40 to-purple-800/40 backdrop-blur-xl rounded-2xl p-6 border border-rose-500/30 animate-slide-left"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <h3 className="text-xl font-bold text-rose-300 mb-3">Q: {faq.q}</h3>
                <p className="text-rose-100">A: {faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}