import { useLocation, Link } from 'react-router-dom'
import { useState } from 'react'
import OperatorLogo from '../components/OperatorLogo'
import PaymentReceipt from '../components/PaymentReceipt'

export default function Success(){
  const { state } = useLocation()
  const [showReceipt, setShowReceipt] = useState(false)
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#071226] via-[#081425] to-[#0a1628] flex items-center justify-center p-6">
      <div className="max-w-2xl w-full">
        {/* Success Animation */}
        <div className="text-center mb-8">
          <div className="relative">
            <div className="w-32 h-32 mx-auto mb-6 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center animate-float shadow-2xl">
              <div className="text-6xl animate-bounce">✅</div>
            </div>
            <div className="absolute inset-0 w-32 h-32 mx-auto bg-gradient-to-r from-green-400 to-emerald-500 rounded-full opacity-20 animate-ping"></div>
          </div>
        </div>

        {/* Success Card */}
        <div className="card animate-slide-right">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold text-gradient mb-3">🎉 Recharge Successful!</h2>
            <p className="text-gray-400 text-lg">Your mobile recharge has been processed successfully</p>
          </div>
          
          {/* Transaction Summary */}
          <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-3xl p-8 mb-8">
            <div className="flex items-center justify-center gap-4 mb-6">
              <OperatorLogo operator={state?.operator} size="xl" />
              <div className="text-center">
                <div className="text-5xl font-bold text-gradient">₹{state?.amount}</div>
                <div className="text-gray-400">Recharged Successfully</div>
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-white mb-2">{state?.mobile}</div>
              <div className="text-gray-400">{state?.planTitle}</div>
            </div>
          </div>
          
          {/* Transaction Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <div className="card bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20">
              <div className="text-center">
                <div className="text-3xl mb-2">🆔</div>
                <div className="text-sm text-gray-400 mb-1">Transaction ID</div>
                <div className="text-white font-mono text-sm">{state?.id || 'TXN' + Date.now()}</div>
              </div>
            </div>
            
            <div className="card bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20">
              <div className="text-center">
                <div className="text-3xl mb-2">📅</div>
                <div className="text-sm text-gray-400 mb-1">Date & Time</div>
                <div className="text-white text-sm">
                  {new Date().toLocaleString('en-IN', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </div>
              </div>
            </div>
            
            <div className="card bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/20">
              <div className="text-center">
                <div className="text-3xl mb-2">💳</div>
                <div className="text-sm text-gray-400 mb-1">Payment Method</div>
                <div className="text-white text-sm">Digital Wallet</div>
              </div>
            </div>
            
            <div className="card bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20">
              <div className="text-center">
                <div className="text-3xl mb-2">✅</div>
                <div className="text-sm text-gray-400 mb-1">Status</div>
                <div className="status-success">Completed</div>
              </div>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <button
              onClick={() => setShowReceipt(true)}
              className="btn-success flex items-center justify-center gap-2"
            >
              🧾 View Receipt
            </button>
            
            <Link 
              to="/history" 
              className="btn-secondary flex items-center justify-center gap-2 text-center"
            >
              📊 View History
            </Link>
          </div>
          
          {/* Navigation Buttons */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link 
              to="/plans" 
              className="btn-primary flex items-center justify-center gap-2 text-center"
            >
              🔄 Recharge Again
            </Link>
            
            <Link 
              to="/" 
              className="btn-secondary flex items-center justify-center gap-2 text-center"
            >
              🏠 Back to Home
            </Link>
          </div>
          
          {/* Additional Features */}
          <div className="mt-8 pt-6 border-t border-gray-700">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div className="p-3">
                <div className="text-2xl mb-1">⚡</div>
                <div className="text-xs text-gray-400">Instant</div>
              </div>
              <div className="p-3">
                <div className="text-2xl mb-1">🔒</div>
                <div className="text-xs text-gray-400">Secure</div>
              </div>
              <div className="p-3">
                <div className="text-2xl mb-1">💯</div>
                <div className="text-xs text-gray-400">Reliable</div>
              </div>
              <div className="p-3">
                <div className="text-2xl mb-1">🎯</div>
                <div className="text-xs text-gray-400">Accurate</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Footer Message */}
        <div className="text-center mt-8">
          <div className="card inline-block">
            <p className="text-gray-400 text-sm mb-2">
              🌟 Thank you for choosing QuickTopUp!
            </p>
            <p className="text-xs text-gray-500">
              Your trust drives our innovation
            </p>
          </div>
        </div>
      </div>

      {/* Receipt Modal */}
      {showReceipt && (
        <PaymentReceipt 
          recharge={{
            ...state,
            id: state?.id || 'TXN' + Date.now(),
            date: new Date().toISOString()
          }} 
          onClose={() => setShowReceipt(false)} 
        />
      )}
    </div>
  )
}