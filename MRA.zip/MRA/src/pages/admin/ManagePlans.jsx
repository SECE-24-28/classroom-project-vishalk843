import { useState, useEffect } from 'react'
import { addPlan, updatePlan, getPlans } from '../../api/api'
import { useNavigate, useParams } from 'react-router-dom'
import Toast from '../../components/Toast'
import OperatorLogo from '../../components/OperatorLogo'

export default function ManagePlans(){
  const [title, setTitle] = useState('')
  const [amount, setAmount] = useState('')
  const [validity, setValidity] = useState('')
  const [description, setDescription] = useState('')
  const [operator, setOperator] = useState('All')
  const [category, setCategory] = useState('Data')
  const [benefits, setBenefits] = useState([''])
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState(null)
  const nav = useNavigate()
  const { id } = useParams()
  const isEdit = !!id

  useEffect(() => {
    if (isEdit) {
      setLoading(true)
      getPlans().then(r => {
        const plan = r.data.find(p => p.id === id)
        if (plan) {
          setTitle(plan.title || '')
          setAmount(plan.amount?.toString() || '')
          setValidity(plan.validity || '')
          setDescription(plan.description || '')
          setOperator(plan.operator || 'All')
          setCategory(plan.category || 'Data')
          setBenefits(plan.benefits || [''])
        }
        setLoading(false)
      }).catch(() => setLoading(false))
    }
  }, [id, isEdit])

  const submit = async (e) => {
    e.preventDefault()
    if (!title || !amount) return setToast({ message: 'Title and amount are required!', type: 'error' })
    
    setLoading(true)
    try {
      const planData = { 
        title, 
        amount: Number(amount), 
        validity, 
        description, 
        operator, 
        category, 
        benefits: benefits.filter(b => b.trim() !== '') 
      }
      
      if (isEdit) {
        await updatePlan(id, planData)
        setToast({ message: '✅ Plan updated successfully!', type: 'success' })
      } else {
        await addPlan(planData)
        setToast({ message: '🎉 Plan created successfully!', type: 'success' })
      }
      setTimeout(() => nav('/admin/dashboard'), 1500)
    } catch (error) {
      setToast({ message: '❌ Error saving plan: ' + error.message, type: 'error' })
      setLoading(false)
    }
  }

  if (loading && isEdit) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-900 via-orange-900 to-red-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 border-4 border-amber-300 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
          <div className="text-2xl font-bold bg-gradient-to-r from-amber-400 to-orange-400 bg-clip-text text-transparent">
            Loading plan details...
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-900 via-orange-900 to-red-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-6xl font-black bg-gradient-to-r from-amber-400 via-orange-400 to-red-400 bg-clip-text text-transparent mb-4 animate-glow">
            {isEdit ? '✏️ EDIT PLAN' : '➕ CREATE PLAN'}
          </h1>
          <p className="text-2xl text-amber-200">
            {isEdit ? 'Modify existing recharge plan' : 'Design a new recharge plan for customers'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Form Section */}
          <div className="bg-gradient-to-br from-amber-800/40 to-red-800/40 backdrop-blur-xl rounded-3xl p-8 border border-amber-500/30">
            <form onSubmit={submit} className="space-y-6">
              <h2 className="text-3xl font-bold text-amber-300 mb-6 text-center">📝 Plan Details</h2>
              
              {/* Plan Title */}
              <div>
                <label className="block text-amber-300 text-sm font-bold mb-2">
                  📱 Plan Title
                </label>
                <input 
                  className="input-field"
                  placeholder="e.g., Premium Unlimited Plan" 
                  value={title} 
                  onChange={e => setTitle(e.target.value)}
                  disabled={loading}
                  required
                />
              </div>

              {/* Amount */}
              <div>
                <label className="block text-amber-300 text-sm font-bold mb-2">
                  💰 Amount (₹)
                </label>
                <input 
                  className="input-field"
                  placeholder="e.g., 199" 
                  type="number"
                  min="1"
                  value={amount} 
                  onChange={e => setAmount(e.target.value)}
                  disabled={loading}
                  required
                />
              </div>

              {/* Validity */}
              <div>
                <label className="block text-amber-300 text-sm font-bold mb-2">
                  ⏰ Validity Period
                </label>
                <input 
                  className="input-field"
                  placeholder="e.g., 28 days, 3 months" 
                  value={validity} 
                  onChange={e => setValidity(e.target.value)}
                  disabled={loading}
                />
              </div>

              {/* Operator */}
              <div>
                <label className="block text-amber-300 text-sm font-bold mb-2">
                  📡 Network Operator
                </label>
                <select 
                  className="input-field"
                  value={operator} 
                  onChange={e => setOperator(e.target.value)}
                  disabled={loading}
                >
                  <option value="All">📱 All Operators</option>
                  <option value="Airtel">🔴 Airtel</option>
                  <option value="Jio">🔵 Jio</option>
                  <option value="Vi">🟡 Vi (Vodafone Idea)</option>
                  <option value="BSNL">🟢 BSNL</option>
                </select>
              </div>

              {/* Category */}
              <div>
                <label className="block text-amber-300 text-sm font-bold mb-2">
                  🎯 Plan Category
                </label>
                <select 
                  className="input-field"
                  value={category} 
                  onChange={e => setCategory(e.target.value)}
                  disabled={loading}
                >
                  <option value="Data">📊 Data Plan</option>
                  <option value="Top-up">💰 Top-up</option>
                  <option value="Voice">📞 Voice Plan</option>
                  <option value="Combo">🎁 Combo Plan</option>
                </select>
              </div>

              {/* Description */}
              <div>
                <label className="block text-amber-300 text-sm font-bold mb-2">
                  📝 Description
                </label>
                <textarea 
                  className="input-field resize-none"
                  placeholder="Brief description of the plan..." 
                  rows="3"
                  value={description} 
                  onChange={e => setDescription(e.target.value)}
                  disabled={loading}
                />
              </div>

              {/* Benefits */}
              <div>
                <label className="block text-amber-300 text-sm font-bold mb-2">
                  ✨ Plan Benefits
                </label>
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex gap-2 mb-3">
                    <input 
                      className="input-field flex-1"
                      placeholder={`Benefit ${index + 1} (e.g., Unlimited Voice Calls)`}
                      value={benefit}
                      onChange={e => {
                        const newBenefits = [...benefits]
                        newBenefits[index] = e.target.value
                        setBenefits(newBenefits)
                      }}
                      disabled={loading}
                    />
                    {benefits.length > 1 && (
                      <button 
                        type="button"
                        onClick={() => setBenefits(benefits.filter((_, i) => i !== index))}
                        className="px-4 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-2xl hover:scale-105 transition-all"
                        disabled={loading}
                      >
                        🗑️
                      </button>
                    )}
                  </div>
                ))}
                <button 
                  type="button"
                  onClick={() => setBenefits([...benefits, ''])}
                  className="w-full py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-2xl font-bold hover:scale-105 transition-all"
                  disabled={loading}
                >
                  ➕ Add Benefit
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4 pt-6">
                <button 
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-2xl font-bold text-lg hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      {isEdit ? 'Updating...' : 'Creating...'}
                    </div>
                  ) : (
                    `${isEdit ? '💾 Update Plan' : '🚀 Create Plan'}`
                  )}
                </button>
                
                <button 
                  type="button"
                  onClick={() => nav('/admin/dashboard')}
                  className="flex-1 py-4 bg-gradient-to-r from-gray-600 to-gray-700 text-white rounded-2xl font-bold text-lg hover:scale-105 transition-all"
                  disabled={loading}
                >
                  ❌ Cancel
                </button>
              </div>
            </form>
          </div>

          {/* Preview Section */}
          <div className="bg-gradient-to-br from-amber-800/40 to-red-800/40 backdrop-blur-xl rounded-3xl p-8 border border-amber-500/30">
            <h2 className="text-3xl font-bold text-amber-300 mb-6 text-center">👁️ Live Preview</h2>
            
            <div className="bg-gradient-to-br from-amber-900/50 to-red-900/50 rounded-3xl p-6 border border-amber-600/30">
              {/* Operator Logo */}
              <div className="flex justify-between items-start mb-6">
                <OperatorLogo operator={operator} size="lg" />
                <div className="text-xs text-amber-400 bg-amber-900/50 px-3 py-2 rounded-full">
                  {category}
                </div>
              </div>
              
              {/* Plan Details */}
              <div className="text-center mb-6">
                <div className="text-5xl font-bold text-amber-300 mb-2">
                  ₹{amount || '0'}
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  {title || 'Plan Title'}
                </h3>
                <p className="text-amber-200">
                  ⏰ {validity || 'Validity Period'}
                </p>
              </div>
              
              {/* Description */}
              <div className="mb-6">
                <p className="text-amber-100 text-center">
                  {description || 'Plan description will appear here...'}
                </p>
              </div>
              
              {/* Benefits */}
              {benefits.filter(b => b.trim()).length > 0 && (
                <div className="mb-6">
                  <div className="text-sm font-bold text-amber-400 mb-3">✨ Benefits:</div>
                  <div className="space-y-2">
                    {benefits.filter(b => b.trim()).map((benefit, idx) => (
                      <div key={idx} className="flex items-center text-sm text-amber-200">
                        <span className="text-green-400 mr-3">✓</span>
                        {benefit}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Mock Button */}
              <button className="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-2xl font-bold hover:scale-105 transition-all">
                🚀 Recharge Now
              </button>
            </div>
            
            {/* Preview Info */}
            <div className="mt-6 text-center">
              <p className="text-amber-300 text-sm">
                👆 This is how customers will see your plan
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Toast Notification */}
      {toast && (
        <Toast 
          message={toast.message} 
          type={toast.type} 
          onClose={() => setToast(null)} 
        />
      )}
    </div>
  )
}