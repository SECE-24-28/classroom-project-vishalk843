import { useEffect, useState } from 'react'
import { getPlans, deletePlan, getRecharges } from '../../api/api'
import { Link } from 'react-router-dom'

export default function AdminDashboard(){
  const [plans, setPlans] = useState([])
  const [recharges, setRecharges] = useState([])
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('overview')
  const [selectedPlan, setSelectedPlan] = useState(null)

  const loadData = () => {
    Promise.all([getPlans(), getRecharges()])
      .then(([planRes, rechargeRes]) => {
        setPlans(planRes.data || [])
        setRecharges(rechargeRes.data || [])
      })
      .catch(err => {
        console.error('Error loading data:', err)
        setPlans([])
        setRecharges([])
      })
  }

  useEffect(() => { loadData() }, [])

  const handleDelete = async (id) => {
    if (!confirm('⚠️ Are you sure you want to delete this plan? This action cannot be undone.')) return
    setLoading(true)
    try {
      await deletePlan(id)
      loadData()
    } catch (error) {
      alert('❌ Error deleting plan: ' + error.message)
    }
    setLoading(false)
  }

  const downloadReport = (type = 'plans') => {
    const data = type === 'plans' ? plans : recharges
    const headers = type === 'plans' 
      ? ['ID', 'Title', 'Amount', 'Validity', 'Operator', 'Category', 'Description']
      : ['ID', 'Mobile', 'Amount', 'Plan', 'Operator', 'Employee', 'Status', 'Date']
    
    const csvContent = [
      headers,
      ...data.map(item => type === 'plans' 
        ? [item.id, item.title, item.amount, item.validity, item.operator, item.category, item.description]
        : [item.id, item.mobile, item.amount, item.planTitle, item.operator, item.employee, item.status, new Date(item.date).toLocaleString()]
      )
    ].map(row => row.join(',')).join('\n')
    
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `Admin-${type}-Report-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  const stats = {
    totalPlans: plans.length,
    totalRecharges: recharges.length,
    successfulRecharges: recharges.filter(r => r.status === 'success').length,
    totalRevenue: recharges.reduce((sum, r) => sum + (r.amount || 0), 0),
    operators: [...new Set(plans.map(p => p.operator).filter(Boolean))].length
  }

  const tabs = [
    { id: 'overview', label: '📊 Overview', icon: '📊' },
    { id: 'plans', label: '📱 Plans Management', icon: '📱' },
    { id: 'transactions', label: '💳 Transactions', icon: '💳' },
    { id: 'analytics', label: '📈 Analytics', icon: '📈' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-900 via-orange-900 to-red-900">
      {/* Admin Header */}
      <div className="bg-gradient-to-r from-amber-800/40 to-red-800/40 backdrop-blur-xl border-b border-amber-500/30 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div className="mb-6 lg:mb-0">
              <h1 className="text-6xl font-black bg-gradient-to-r from-amber-400 via-orange-400 to-red-400 bg-clip-text text-transparent mb-3 animate-glow">
                👑 ADMIN COMMAND CENTER
              </h1>
              <p className="text-2xl text-amber-200">
                Master Control Panel - Total System Authority
              </p>
            </div>
            
            <div className="flex gap-4">
              <button
                onClick={() => downloadReport('plans')}
                className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-2xl font-bold hover:scale-105 transition-all shadow-lg"
              >
                📊 Export Plans
              </button>
              <button
                onClick={() => downloadReport('transactions')}
                className="px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-2xl font-bold hover:scale-105 transition-all shadow-lg"
              >
                💾 Export Data
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-8">
        {/* Tab Navigation */}
        <div className="flex flex-wrap justify-center gap-4 mb-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-8 py-4 rounded-2xl font-bold text-lg transition-all duration-300 ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-2xl shadow-amber-500/30 scale-110'
                  : 'bg-amber-800/30 text-amber-300 hover:bg-amber-700/40 backdrop-blur-sm border border-amber-600/30'
              }`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
              <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl rounded-3xl p-6 border border-blue-400/30 text-center hover:scale-105 transition-all">
                <div className="text-5xl mb-3 animate-bounce">📱</div>
                <div className="text-4xl font-bold text-cyan-300">{stats.totalPlans}</div>
                <div className="text-cyan-200">Total Plans</div>
              </div>
              
              <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl rounded-3xl p-6 border border-green-400/30 text-center hover:scale-105 transition-all">
                <div className="text-5xl mb-3 animate-pulse">💳</div>
                <div className="text-4xl font-bold text-emerald-300">{stats.totalRecharges}</div>
                <div className="text-emerald-200">Transactions</div>
              </div>
              
              <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-xl rounded-3xl p-6 border border-purple-400/30 text-center hover:scale-105 transition-all">
                <div className="text-5xl mb-3 animate-spin">✅</div>
                <div className="text-4xl font-bold text-purple-300">{stats.successfulRecharges}</div>
                <div className="text-purple-200">Successful</div>
              </div>
              
              <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 backdrop-blur-xl rounded-3xl p-6 border border-yellow-400/30 text-center hover:scale-105 transition-all">
                <div className="text-5xl mb-3 animate-float">💰</div>
                <div className="text-3xl font-bold text-yellow-300">₹{stats.totalRevenue}</div>
                <div className="text-yellow-200">Revenue</div>
              </div>
              
              <div className="bg-gradient-to-br from-red-500/20 to-pink-500/20 backdrop-blur-xl rounded-3xl p-6 border border-red-400/30 text-center hover:scale-105 transition-all">
                <div className="text-5xl mb-3 animate-pulse">📡</div>
                <div className="text-4xl font-bold text-red-300">{stats.operators}</div>
                <div className="text-red-200">Operators</div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-br from-amber-800/40 to-red-800/40 backdrop-blur-xl rounded-3xl p-8 border border-amber-500/30">
              <h2 className="text-3xl font-bold text-amber-300 mb-6 text-center">⚡ Quick Actions</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Link
                  to="/admin/create"
                  className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl rounded-2xl p-6 border border-green-400/30 text-center hover:scale-105 transition-all"
                >
                  <div className="text-4xl mb-3 animate-bounce">➕</div>
                  <h3 className="text-xl font-bold text-green-300">Create Plan</h3>
                  <p className="text-green-200 text-sm">Add new recharge plan</p>
                </Link>
                
                <button
                  onClick={() => setActiveTab('plans')}
                  className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl rounded-2xl p-6 border border-blue-400/30 text-center hover:scale-105 transition-all"
                >
                  <div className="text-4xl mb-3 animate-pulse">📱</div>
                  <h3 className="text-xl font-bold text-blue-300">Manage Plans</h3>
                  <p className="text-blue-200 text-sm">Edit existing plans</p>
                </button>
                
                <button
                  onClick={() => setActiveTab('transactions')}
                  className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-xl rounded-2xl p-6 border border-purple-400/30 text-center hover:scale-105 transition-all"
                >
                  <div className="text-4xl mb-3 animate-float">💳</div>
                  <h3 className="text-xl font-bold text-purple-300">View Transactions</h3>
                  <p className="text-purple-200 text-sm">Monitor all recharges</p>
                </button>
                
                <button
                  onClick={() => setActiveTab('analytics')}
                  className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-xl rounded-2xl p-6 border border-orange-400/30 text-center hover:scale-105 transition-all"
                >
                  <div className="text-4xl mb-3 animate-spin">📈</div>
                  <h3 className="text-xl font-bold text-orange-300">Analytics</h3>
                  <p className="text-orange-200 text-sm">View detailed reports</p>
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'plans' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-4xl font-bold text-amber-300">📱 Plans Management</h2>
              <Link
                to="/admin/create"
                className="px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-2xl font-bold hover:scale-105 transition-all shadow-lg"
              >
                ➕ Create New Plan
              </Link>
            </div>
            
            {plans.length === 0 ? (
              <div className="text-center py-20">
                <div className="text-8xl mb-6 animate-float">📱</div>
                <h3 className="text-3xl font-bold text-amber-300 mb-4">No Plans Available</h3>
                <p className="text-amber-200 mb-8">Create your first recharge plan to get started</p>
                <Link
                  to="/admin/create"
                  className="inline-block px-12 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-2xl font-bold hover:scale-105 transition-all"
                >
                  🚀 Create First Plan
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {plans.map((plan, index) => (
                  <div
                    key={plan.id}
                    className="bg-gradient-to-br from-amber-800/40 to-red-800/40 backdrop-blur-xl rounded-3xl p-6 border border-amber-500/30 hover:scale-105 transition-all animate-slide-right"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className={`px-3 py-1 rounded-full text-xs font-bold ${
                        plan.operator === 'Airtel' ? 'bg-red-500' :
                        plan.operator === 'Jio' ? 'bg-blue-500' :
                        plan.operator === 'Vi' ? 'bg-purple-500' :
                        plan.operator === 'BSNL' ? 'bg-green-500' : 'bg-gray-500'
                      } text-white`}>
                        {plan.operator}
                      </div>
                      <div className="text-xs text-amber-400 bg-amber-900/50 px-2 py-1 rounded">
                        {plan.category}
                      </div>
                    </div>
                    
                    <div className="text-center mb-6">
                      <div className="text-4xl font-bold text-amber-300 mb-2">₹{plan.amount}</div>
                      <h3 className="text-xl font-bold text-white mb-1">{plan.title}</h3>
                      <p className="text-amber-200 text-sm">Valid for {plan.validity}</p>
                    </div>
                    
                    <p className="text-amber-100 text-sm mb-4 text-center">{plan.description}</p>
                    
                    {plan.benefits && (
                      <div className="mb-6">
                        <div className="text-sm font-semibold text-amber-400 mb-2">✨ Benefits:</div>
                        <div className="space-y-1">
                          {plan.benefits.slice(0, 2).map((benefit, idx) => (
                            <div key={idx} className="flex items-center text-xs text-amber-200">
                              <span className="text-green-400 mr-2">✓</span>
                              {benefit}
                            </div>
                          ))}
                          {plan.benefits.length > 2 && (
                            <div className="text-xs text-amber-400">
                              +{plan.benefits.length - 2} more benefits
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                    
                    <div className="flex gap-2">
                      <Link
                        to={`/admin/edit/${plan.id}`}
                        className="flex-1 px-4 py-2 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-xl font-bold text-center hover:scale-105 transition-all"
                      >
                        ✏️ Edit
                      </Link>
                      <button
                        onClick={() => handleDelete(plan.id)}
                        disabled={loading}
                        className="flex-1 px-4 py-2 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-xl font-bold hover:scale-105 transition-all disabled:opacity-50"
                      >
                        🗑️ Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'transactions' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-4xl font-bold text-amber-300">💳 All Transactions</h2>
              <div className="text-amber-200">
                Total: {recharges.length} transactions
              </div>
            </div>
            
            {recharges.length === 0 ? (
              <div className="text-center py-20">
                <div className="text-8xl mb-6 animate-float">💳</div>
                <h3 className="text-3xl font-bold text-amber-300 mb-4">No Transactions Yet</h3>
                <p className="text-amber-200">Transactions will appear here once users start recharging</p>
              </div>
            ) : (
              <div className="bg-gradient-to-br from-amber-800/40 to-red-800/40 backdrop-blur-xl rounded-3xl border border-amber-500/30 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gradient-to-r from-amber-900/50 to-red-900/50">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-bold text-amber-200">Status</th>
                        <th className="px-6 py-4 text-left text-sm font-bold text-amber-200">Mobile</th>
                        <th className="px-6 py-4 text-left text-sm font-bold text-amber-200">Amount</th>
                        <th className="px-6 py-4 text-left text-sm font-bold text-amber-200">Plan</th>
                        <th className="px-6 py-4 text-left text-sm font-bold text-amber-200">Employee</th>
                        <th className="px-6 py-4 text-left text-sm font-bold text-amber-200">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-amber-500/20">
                      {recharges.slice(0, 10).map((recharge) => (
                        <tr key={recharge.id} className="hover:bg-amber-800/20 transition-all">
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${
                              recharge.status === 'success' ? 'bg-green-500' :
                              recharge.status === 'failed' ? 'bg-red-500' : 'bg-yellow-500'
                            } text-white`}>
                              {recharge.status === 'success' ? '✅' : recharge.status === 'failed' ? '❌' : '⏳'} {recharge.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-white font-mono">{recharge.mobile}</td>
                          <td className="px-6 py-4 text-2xl font-bold text-amber-300">₹{recharge.amount}</td>
                          <td className="px-6 py-4 text-amber-100">{recharge.planTitle || recharge.planId}</td>
                          <td className="px-6 py-4 text-amber-100">{recharge.employee}</td>
                          <td className="px-6 py-4 text-amber-100 text-sm">
                            {new Date(recharge.date).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-8">
            <h2 className="text-4xl font-bold text-amber-300 text-center">📈 Advanced Analytics</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Revenue Chart Placeholder */}
              <div className="bg-gradient-to-br from-amber-800/40 to-red-800/40 backdrop-blur-xl rounded-3xl p-8 border border-amber-500/30">
                <h3 className="text-2xl font-bold text-amber-300 mb-6">💰 Revenue Overview</h3>
                <div className="text-center py-12">
                  <div className="text-6xl mb-4 animate-pulse">📊</div>
                  <div className="text-4xl font-bold text-amber-300 mb-2">₹{stats.totalRevenue}</div>
                  <div className="text-amber-200">Total Revenue Generated</div>
                </div>
              </div>
              
              {/* Success Rate */}
              <div className="bg-gradient-to-br from-amber-800/40 to-red-800/40 backdrop-blur-xl rounded-3xl p-8 border border-amber-500/30">
                <h3 className="text-2xl font-bold text-amber-300 mb-6">📈 Success Rate</h3>
                <div className="text-center py-12">
                  <div className="text-6xl mb-4 animate-spin">🎯</div>
                  <div className="text-4xl font-bold text-green-300 mb-2">
                    {stats.totalRecharges ? Math.round((stats.successfulRecharges / stats.totalRecharges) * 100) : 0}%
                  </div>
                  <div className="text-amber-200">Transaction Success Rate</div>
                </div>
              </div>
            </div>
            
            {/* Operator Performance */}
            <div className="bg-gradient-to-br from-amber-800/40 to-red-800/40 backdrop-blur-xl rounded-3xl p-8 border border-amber-500/30">
              <h3 className="text-2xl font-bold text-amber-300 mb-6">📡 Operator Performance</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {['Airtel', 'Jio', 'Vi', 'BSNL'].map((operator) => {
                  const operatorRecharges = recharges.filter(r => r.operator === operator)
                  const operatorRevenue = operatorRecharges.reduce((sum, r) => sum + (r.amount || 0), 0)
                  return (
                    <div key={operator} className="text-center bg-amber-900/30 rounded-2xl p-6">
                      <div className={`text-4xl mb-3 ${
                        operator === 'Airtel' ? 'text-red-400' :
                        operator === 'Jio' ? 'text-blue-400' :
                        operator === 'Vi' ? 'text-purple-400' : 'text-green-400'
                      }`}>
                        {operator === 'Airtel' ? '🔴' : operator === 'Jio' ? '🔵' : operator === 'Vi' ? '🟣' : '🟢'}
                      </div>
                      <div className="text-xl font-bold text-amber-300">{operator}</div>
                      <div className="text-amber-200 text-sm">{operatorRecharges.length} transactions</div>
                      <div className="text-amber-300 font-bold">₹{operatorRevenue}</div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}