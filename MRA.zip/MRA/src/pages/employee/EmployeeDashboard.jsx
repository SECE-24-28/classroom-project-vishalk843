import { useEffect, useState } from 'react'
import { getPlans, getRecharges } from '../../api/api'
import { Link } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import OperatorLogo from '../../components/OperatorLogo'
import PaymentReceipt from '../../components/PaymentReceipt'

export default function EmployeeDashboard(){
  const { user } = useAuth()
  const [plans, setPlans] = useState([])
  const [recharges, setRecharges] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeView, setActiveView] = useState('dashboard')
  const [selectedOperator, setSelectedOperator] = useState('all')
  const [showReceipt, setShowReceipt] = useState(false)
  const [selectedRecharge, setSelectedRecharge] = useState(null)

  useEffect(() => {
    Promise.all([getPlans(), getRecharges()])
      .then(([planRes, rechargeRes]) => {
        setPlans(planRes.data || [])
        // Filter recharges for current employee
        const employeeRecharges = (rechargeRes.data || []).filter(r => r.employeeId === user?.id)
        setRecharges(employeeRecharges)
        setLoading(false)
      })
      .catch(err => {
        console.error('Error loading data:', err)
        setPlans([])
        setRecharges([])
        setLoading(false)
      })
  }, [user])

  const downloadMyReport = () => {
    const csvContent = [
      ['Date', 'Mobile', 'Amount', 'Plan', 'Operator', 'Status', 'Transaction ID'],
      ...recharges.map(r => [
        new Date(r.date).toLocaleString(),
        r.mobile,
        r.amount,
        r.planTitle || r.planId,
        r.operator || 'N/A',
        r.status,
        r.id
      ])
    ].map(row => row.join(',')).join('\n')
    
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `My-Recharge-Report-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  const filteredPlans = selectedOperator === 'all' 
    ? plans 
    : plans.filter(p => p.operator === selectedOperator)

  const stats = {
    totalRecharges: recharges.length,
    successfulRecharges: recharges.filter(r => r.status === 'success').length,
    totalAmount: recharges.reduce((sum, r) => sum + (r.amount || 0), 0),
    avgAmount: recharges.length ? Math.round(recharges.reduce((sum, r) => sum + (r.amount || 0), 0) / recharges.length) : 0,
    todayRecharges: recharges.filter(r => {
      const today = new Date().toDateString()
      return new Date(r.date).toDateString() === today
    }).length
  }

  const operators = [...new Set(plans.map(p => p.operator).filter(Boolean))]

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-teal-900 via-cyan-900 to-blue-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 border-4 border-teal-300 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
          <div className="text-2xl font-bold bg-gradient-to-r from-teal-400 to-cyan-400 bg-clip-text text-transparent">
            Loading Employee Portal...
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-900 via-cyan-900 to-blue-900">
      {/* Employee Header */}
      <div className="bg-gradient-to-r from-teal-800/40 to-blue-800/40 backdrop-blur-xl border-b border-teal-500/30 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div className="mb-6 lg:mb-0">
              <h1 className="text-6xl font-black bg-gradient-to-r from-teal-400 via-cyan-400 to-blue-400 bg-clip-text text-transparent mb-3 animate-glow">
                👤 EMPLOYEE WORKSPACE
              </h1>
              <p className="text-2xl text-teal-200">
                Welcome back, {user?.name}! Ready to serve customers? 🚀
              </p>
            </div>
            
            <div className="flex gap-4">
              <button
                onClick={downloadMyReport}
                className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-2xl font-bold hover:scale-105 transition-all shadow-lg"
              >
                📊 My Report
              </button>
              <Link
                to="/history"
                className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl font-bold hover:scale-105 transition-all shadow-lg"
              >
                📋 Full History
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-8">
        {/* View Toggle */}
        <div className="flex justify-center gap-4 mb-8">
          {[
            { id: 'dashboard', label: '📊 Dashboard', icon: '📊' },
            { id: 'plans', label: '📱 Quick Recharge', icon: '📱' },
            { id: 'history', label: '📋 My History', icon: '📋' }
          ].map((view) => (
            <button
              key={view.id}
              onClick={() => setActiveView(view.id)}
              className={`px-8 py-4 rounded-2xl font-bold text-lg transition-all duration-300 ${
                activeView === view.id
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white shadow-2xl shadow-teal-500/30 scale-110'
                  : 'bg-teal-800/30 text-teal-300 hover:bg-teal-700/40 backdrop-blur-sm border border-teal-600/30'
              }`}
            >
              {view.icon} {view.label}
            </button>
          ))}
        </div>

        {/* Dashboard View */}
        {activeView === 'dashboard' && (
          <div className="space-y-8">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
              <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl rounded-3xl p-6 border border-blue-400/30 text-center hover:scale-105 transition-all">
                <div className="text-5xl mb-3 animate-bounce">📊</div>
                <div className="text-4xl font-bold text-cyan-300">{stats.totalRecharges}</div>
                <div className="text-cyan-200">Total Done</div>
              </div>
              
              <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl rounded-3xl p-6 border border-green-400/30 text-center hover:scale-105 transition-all">
                <div className="text-5xl mb-3 animate-pulse">✅</div>
                <div className="text-4xl font-bold text-emerald-300">{stats.successfulRecharges}</div>
                <div className="text-emerald-200">Successful</div>
              </div>
              
              <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-xl rounded-3xl p-6 border border-purple-400/30 text-center hover:scale-105 transition-all">
                <div className="text-5xl mb-3 animate-float">💰</div>
                <div className="text-3xl font-bold text-purple-300">₹{stats.totalAmount}</div>
                <div className="text-purple-200">Total Value</div>
              </div>
              
              <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 backdrop-blur-xl rounded-3xl p-6 border border-yellow-400/30 text-center hover:scale-105 transition-all">
                <div className="text-5xl mb-3 animate-spin">📈</div>
                <div className="text-3xl font-bold text-yellow-300">₹{stats.avgAmount}</div>
                <div className="text-yellow-200">Average</div>
              </div>
              
              <div className="bg-gradient-to-br from-red-500/20 to-pink-500/20 backdrop-blur-xl rounded-3xl p-6 border border-red-400/30 text-center hover:scale-105 transition-all">
                <div className="text-5xl mb-3 animate-pulse">🌅</div>
                <div className="text-4xl font-bold text-red-300">{stats.todayRecharges}</div>
                <div className="text-red-200">Today</div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-br from-teal-800/40 to-blue-800/40 backdrop-blur-xl rounded-3xl p-8 border border-teal-500/30">
              <h2 className="text-3xl font-bold text-teal-300 mb-6 text-center">⚡ Quick Actions</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <button
                  onClick={() => setActiveView('plans')}
                  className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl rounded-2xl p-6 border border-green-400/30 text-center hover:scale-105 transition-all"
                >
                  <div className="text-4xl mb-3 animate-bounce">📱</div>
                  <h3 className="text-xl font-bold text-green-300">New Recharge</h3>
                  <p className="text-green-200 text-sm">Start mobile recharge</p>
                </button>
                
                <button
                  onClick={() => setActiveView('history')}
                  className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl rounded-2xl p-6 border border-blue-400/30 text-center hover:scale-105 transition-all"
                >
                  <div className="text-4xl mb-3 animate-pulse">📋</div>
                  <h3 className="text-xl font-bold text-blue-300">My History</h3>
                  <p className="text-blue-200 text-sm">View my transactions</p>
                </button>
                
                <Link
                  to="/plans"
                  className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-xl rounded-2xl p-6 border border-purple-400/30 text-center hover:scale-105 transition-all block"
                >
                  <div className="text-4xl mb-3 animate-float">🎯</div>
                  <h3 className="text-xl font-bold text-purple-300">Browse Plans</h3>
                  <p className="text-purple-200 text-sm">View all available plans</p>
                </Link>
                
                <button
                  onClick={downloadMyReport}
                  className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-xl rounded-2xl p-6 border border-orange-400/30 text-center hover:scale-105 transition-all"
                >
                  <div className="text-4xl mb-3 animate-spin">📊</div>
                  <h3 className="text-xl font-bold text-orange-300">Download Report</h3>
                  <p className="text-orange-200 text-sm">Export my data</p>
                </button>
              </div>
            </div>

            {/* Performance Chart */}
            <div className="bg-gradient-to-br from-teal-800/40 to-blue-800/40 backdrop-blur-xl rounded-3xl p-8 border border-teal-500/30">
              <h2 className="text-3xl font-bold text-teal-300 mb-6 text-center">📈 My Performance</h2>
              <div className="text-center py-12">
                <div className="text-8xl mb-6 animate-pulse">🏆</div>
                <div className="text-4xl font-bold text-teal-300 mb-2">
                  {stats.totalRecharges ? Math.round((stats.successfulRecharges / stats.totalRecharges) * 100) : 0}%
                </div>
                <div className="text-teal-200 text-xl">Success Rate</div>
                <div className="mt-4 text-teal-300">
                  Keep up the excellent work! 🌟
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Plans View */}
        {activeView === 'plans' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <h2 className="text-4xl font-bold text-teal-300 mb-4 md:mb-0">📱 Quick Recharge Center</h2>
              <select
                className="px-4 py-3 bg-teal-900/50 border border-teal-400/30 rounded-2xl text-white focus:border-cyan-400 transition-all"
                value={selectedOperator}
                onChange={(e) => setSelectedOperator(e.target.value)}
              >
                <option value="all">🌐 All Operators</option>
                {operators.map(op => (
                  <option key={op} value={op}>{op}</option>
                ))}
              </select>
            </div>
            
            {filteredPlans.length === 0 ? (
              <div className="text-center py-20">
                <div className="text-8xl mb-6 animate-float">📱</div>
                <h3 className="text-3xl font-bold text-teal-300 mb-4">No Plans Available</h3>
                <p className="text-teal-200">Please contact admin to add recharge plans</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredPlans.map((plan, index) => (
                  <div
                    key={plan.id}
                    className="bg-gradient-to-br from-teal-800/40 to-blue-800/40 backdrop-blur-xl rounded-3xl p-6 border border-teal-500/30 hover:scale-105 transition-all animate-slide-right"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <OperatorLogo operator={plan.operator} size="md" />
                      <div className="text-xs text-teal-400 bg-teal-900/50 px-3 py-1 rounded-full">
                        {plan.category}
                      </div>
                    </div>
                    
                    <div className="text-center mb-6">
                      <div className="text-4xl font-bold text-teal-300 mb-2">₹{plan.amount}</div>
                      <h3 className="text-xl font-bold text-white mb-1">{plan.title}</h3>
                      <p className="text-teal-200 text-sm">⏰ {plan.validity}</p>
                    </div>
                    
                    <p className="text-teal-100 text-sm mb-4 text-center">{plan.description}</p>
                    
                    {plan.benefits && (
                      <div className="mb-6">
                        <div className="text-sm font-semibold text-teal-400 mb-2">✨ Benefits:</div>
                        <div className="space-y-1">
                          {plan.benefits.slice(0, 2).map((benefit, idx) => (
                            <div key={idx} className="flex items-center text-xs text-teal-200">
                              <span className="text-green-400 mr-2">✓</span>
                              {benefit}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <Link
                      to={`/recharge/${plan.id}`}
                      state={plan}
                      className="block w-full text-center px-6 py-3 bg-gradient-to-r from-teal-500 to-cyan-500 text-white rounded-2xl font-bold hover:scale-105 transition-all"
                    >
                      🚀 Recharge Now
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* History View */}
        {activeView === 'history' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-4xl font-bold text-teal-300">📋 My Transaction History</h2>
              <div className="text-teal-200">
                Total: {recharges.length} transactions
              </div>
            </div>
            
            {recharges.length === 0 ? (
              <div className="text-center py-20">
                <div className="text-8xl mb-6 animate-float">📋</div>
                <h3 className="text-3xl font-bold text-teal-300 mb-4">No Transactions Yet</h3>
                <p className="text-teal-200 mb-8">Start processing recharges to build your history</p>
                <button
                  onClick={() => setActiveView('plans')}
                  className="px-12 py-4 bg-gradient-to-r from-teal-500 to-cyan-500 text-white rounded-2xl font-bold hover:scale-105 transition-all"
                >
                  🚀 Start First Recharge
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {recharges.slice(0, 10).map((recharge, index) => (
                  <div
                    key={recharge.id}
                    className="bg-gradient-to-br from-teal-800/40 to-blue-800/40 backdrop-blur-xl rounded-2xl p-6 border border-teal-500/30 hover:bg-teal-700/40 transition-all cursor-pointer animate-slide-right"
                    style={{ animationDelay: `${index * 0.1}s` }}
                    onClick={() => {
                      setSelectedRecharge(recharge)
                      setShowReceipt(true)
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <OperatorLogo operator={recharge.operator} size="md" />
                        <div>
                          <div className="flex items-center gap-3 mb-1">
                            <span className="text-2xl font-bold text-teal-300">₹{recharge.amount}</span>
                            <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                              recharge.status === 'success' ? 'bg-green-500' :
                              recharge.status === 'failed' ? 'bg-red-500' : 'bg-yellow-500'
                            } text-white`}>
                              {recharge.status === 'success' ? '✅' : recharge.status === 'failed' ? '❌' : '⏳'} {recharge.status?.toUpperCase()}
                            </span>
                          </div>
                          <div className="text-teal-200 font-mono">{recharge.mobile}</div>
                          <div className="text-sm text-teal-300">
                            {new Date(recharge.date).toLocaleString()}
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="text-teal-300 text-sm mb-1">Click for receipt</div>
                        <div className="text-2xl animate-bounce">🧾</div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {recharges.length > 10 && (
                  <div className="text-center py-6">
                    <Link
                      to="/history"
                      className="px-8 py-3 bg-gradient-to-r from-teal-500 to-cyan-500 text-white rounded-2xl font-bold hover:scale-105 transition-all"
                    >
                      📋 View All History
                    </Link>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Receipt Modal */}
      {showReceipt && selectedRecharge && (
        <PaymentReceipt 
          recharge={selectedRecharge} 
          onClose={() => {
            setShowReceipt(false)
            setSelectedRecharge(null)
          }} 
        />
      )}
    </div>
  )
}