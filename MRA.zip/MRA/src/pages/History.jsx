import { useEffect, useState } from 'react'
import { getRecharges, getPlans } from '../api/api'
import { useAuth } from '../context/AuthContext'
import OperatorLogo from '../components/OperatorLogo'

export default function History(){
  const [recharges, setRecharges] = useState([])
  const [plans, setPlans] = useState([])
  const [filteredRecharges, setFilteredRecharges] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [dateFilter, setDateFilter] = useState('all')
  const [operatorFilter, setOperatorFilter] = useState('all')
  const [viewMode, setViewMode] = useState('timeline') // timeline, grid, table
  const [selectedRecharge, setSelectedRecharge] = useState(null)
  const { user } = useAuth()

  useEffect(() => {
    Promise.all([getRecharges(), getPlans()])
      .then(([rechargeRes, planRes]) => {
        let data = rechargeRes.data || []
        const planData = planRes.data || []
        setPlans(planData)
        
        if (user?.role === 'employee') {
          data = data.filter(recharge => recharge.employeeId === user.id)
        }
        
        data = data.map(recharge => {
          const plan = planData.find(p => p.id === recharge.planId)
          return {
            ...recharge,
            planTitle: plan?.title || 'Unknown Plan',
            planValidity: plan?.validity || 'N/A',
            planDescription: plan?.description || 'No description'
          }
        })
        
        data.sort((a, b) => new Date(b.date) - new Date(a.date))
        setRecharges(data)
        setFilteredRecharges(data)
        setLoading(false)
      })
      .catch(err => {
        console.error('Error loading data:', err)
        setRecharges([])
        setFilteredRecharges([])
        setLoading(false)
      })
  }, [user])

  useEffect(() => {
    let filtered = [...recharges]
    
    if (searchTerm) {
      filtered = filtered.filter(r => 
        r.mobile?.includes(searchTerm) ||
        r.employee?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.planId?.includes(searchTerm) ||
        r.planTitle?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(r => r.status === statusFilter)
    }
    
    if (operatorFilter !== 'all') {
      filtered = filtered.filter(r => r.operator === operatorFilter)
    }
    
    if (dateFilter !== 'all') {
      const now = new Date()
      const filterDate = new Date()
      
      switch(dateFilter) {
        case 'today':
          filterDate.setHours(0, 0, 0, 0)
          filtered = filtered.filter(r => new Date(r.date) >= filterDate)
          break
        case 'week':
          filterDate.setDate(now.getDate() - 7)
          filtered = filtered.filter(r => new Date(r.date) >= filterDate)
          break
        case 'month':
          filterDate.setMonth(now.getMonth() - 1)
          filtered = filtered.filter(r => new Date(r.date) >= filterDate)
          break
      }
    }
    
    setFilteredRecharges(filtered)
  }, [recharges, searchTerm, statusFilter, dateFilter, operatorFilter])

  const getStatusBadge = (status) => {
    const badges = {
      success: 'bg-gradient-to-r from-emerald-400 to-green-500 text-white shadow-lg shadow-green-500/30',
      failed: 'bg-gradient-to-r from-red-400 to-pink-500 text-white shadow-lg shadow-red-500/30',
      pending: 'bg-gradient-to-r from-amber-400 to-orange-500 text-white shadow-lg shadow-orange-500/30'
    }
    return badges[status] || badges.pending
  }

  const getStatusIcon = (status) => {
    const icons = {
      success: '🎉',
      failed: '💥',
      pending: '⏳'
    }
    return icons[status] || '📱'
  }

  const exportData = () => {
    const csvContent = [
      ['Date', 'Mobile', 'Amount', 'Plan', 'Operator', 'Employee', 'Status', 'Transaction ID'],
      ...filteredRecharges.map(r => [
        new Date(r.date).toLocaleString(),
        r.mobile,
        r.amount,
        r.planTitle,
        r.operator,
        r.employee,
        r.status,
        r.id
      ])
    ].map(row => row.join(',')).join('\n')
    
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `QuickTopUp-History-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  const clearAllFilters = () => {
    setSearchTerm('')
    setStatusFilter('all')
    setDateFilter('all')
    setOperatorFilter('all')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-center">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-purple-300 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
            <div className="absolute inset-0 w-16 h-16 border-4 border-pink-300 border-b-transparent rounded-full animate-spin animate-reverse mx-auto mt-2 ml-2"></div>
          </div>
          <div className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent text-2xl font-bold animate-pulse">
            Loading Your Digital Journey...
          </div>
        </div>
      </div>
    )
  }

  const stats = {
    total: recharges.length,
    success: recharges.filter(r => r.status === 'success').length,
    failed: recharges.filter(r => r.status === 'failed').length,
    pending: recharges.filter(r => r.status === 'pending').length,
    totalAmount: recharges.reduce((sum, r) => sum + (r.amount || 0), 0),
    operators: [...new Set(recharges.map(r => r.operator).filter(Boolean))]
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-pink-400/20 to-purple-600/20 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-cyan-600/20 rounded-full blur-3xl animate-float" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-indigo-400/10 to-purple-600/10 rounded-full blur-3xl animate-pulse"></div>
      </div>

      <div className="relative z-10 p-6 max-w-7xl mx-auto">
        {/* Futuristic Header */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-purple-800/40 to-blue-800/40 backdrop-blur-xl rounded-3xl p-8 border border-purple-500/30 shadow-2xl shadow-purple-500/20">
            <div className="text-center mb-8">
              <h1 className="text-6xl font-black bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent mb-4 animate-glow">
                🚀 RECHARGE UNIVERSE
              </h1>
              <p className="text-xl text-purple-200 font-light">
                {user?.role === 'admin' ? '🌌 Cosmic Transaction Observatory' : '✨ Your Digital Recharge Galaxy'}
              </p>
            </div>

            {/* Advanced Control Panel */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
              <div className="relative">
                <input
                  type="text"
                  placeholder="🔍 Search the cosmos..."
                  className="w-full px-4 py-3 bg-gradient-to-r from-purple-900/50 to-blue-900/50 border border-purple-400/30 rounded-2xl text-white placeholder-purple-300 focus:border-pink-400 focus:ring-4 focus:ring-pink-400/20 transition-all backdrop-blur-sm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-purple-400">🔮</div>
              </div>
              
              <select
                className="px-4 py-3 bg-gradient-to-r from-purple-900/50 to-blue-900/50 border border-purple-400/30 rounded-2xl text-white focus:border-pink-400 transition-all backdrop-blur-sm"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="all">🌟 All Status</option>
                <option value="success">🎉 Success</option>
                <option value="failed">💥 Failed</option>
                <option value="pending">⏳ Pending</option>
              </select>
              
              <select
                className="px-4 py-3 bg-gradient-to-r from-purple-900/50 to-blue-900/50 border border-purple-400/30 rounded-2xl text-white focus:border-pink-400 transition-all backdrop-blur-sm"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
              >
                <option value="all">⏰ All Time</option>
                <option value="today">🌅 Today</option>
                <option value="week">📅 This Week</option>
                <option value="month">🗓️ This Month</option>
              </select>
              
              <select
                className="px-4 py-3 bg-gradient-to-r from-purple-900/50 to-blue-900/50 border border-purple-400/30 rounded-2xl text-white focus:border-pink-400 transition-all backdrop-blur-sm"
                value={operatorFilter}
                onChange={(e) => setOperatorFilter(e.target.value)}
              >
                <option value="all">📡 All Operators</option>
                {stats.operators.map(op => (
                  <option key={op} value={op}>{op}</option>
                ))}
              </select>
              
              <div className="flex gap-2">
                <button
                  onClick={exportData}
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-2xl font-bold hover:shadow-lg hover:shadow-emerald-500/30 transition-all"
                >
                  📊 Export
                </button>
              </div>
            </div>

            {/* View Mode Selector */}
            <div className="flex justify-center gap-2 mb-6">
              {[
                { mode: 'timeline', icon: '📜', label: 'Timeline' },
                { mode: 'grid', icon: '🎯', label: 'Grid' },
                { mode: 'table', icon: '📋', label: 'Table' }
              ].map(({ mode, icon, label }) => (
                <button
                  key={mode}
                  onClick={() => setViewMode(mode)}
                  className={`px-6 py-3 rounded-2xl font-bold transition-all ${
                    viewMode === mode
                      ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white shadow-lg shadow-pink-500/30'
                      : 'bg-purple-800/30 text-purple-300 hover:bg-purple-700/40'
                  }`}
                >
                  {icon} {label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Cosmic Stats Dashboard */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl rounded-2xl p-6 border border-blue-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-2 animate-bounce">🌍</div>
            <div className="text-3xl font-bold text-cyan-300">{stats.total}</div>
            <div className="text-sm text-cyan-200">Total Journeys</div>
          </div>
          
          <div className="bg-gradient-to-br from-emerald-500/20 to-green-500/20 backdrop-blur-xl rounded-2xl p-6 border border-emerald-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-2 animate-pulse">🎉</div>
            <div className="text-3xl font-bold text-emerald-300">{stats.success}</div>
            <div className="text-sm text-emerald-200">Successful</div>
          </div>
          
          <div className="bg-gradient-to-br from-red-500/20 to-pink-500/20 backdrop-blur-xl rounded-2xl p-6 border border-red-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-2 animate-bounce">💥</div>
            <div className="text-3xl font-bold text-red-300">{stats.failed}</div>
            <div className="text-sm text-red-200">Failed</div>
          </div>
          
          <div className="bg-gradient-to-br from-amber-500/20 to-orange-500/20 backdrop-blur-xl rounded-2xl p-6 border border-amber-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-2 animate-spin">⏳</div>
            <div className="text-3xl font-bold text-amber-300">{stats.pending}</div>
            <div className="text-sm text-amber-200">Pending</div>
          </div>
          
          <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-xl rounded-2xl p-6 border border-purple-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-2 animate-float">💰</div>
            <div className="text-2xl font-bold text-purple-300">₹{stats.totalAmount}</div>
            <div className="text-sm text-purple-200">Total Value</div>
          </div>
          
          <div className="bg-gradient-to-br from-indigo-500/20 to-blue-500/20 backdrop-blur-xl rounded-2xl p-6 border border-indigo-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-2 animate-pulse">📡</div>
            <div className="text-3xl font-bold text-indigo-300">{stats.operators.length}</div>
            <div className="text-sm text-indigo-200">Networks</div>
          </div>
        </div>

        {/* Dynamic Content Area */}
        {filteredRecharges.length === 0 ? (
          <div className="text-center py-20">
            <div className="bg-gradient-to-br from-purple-800/40 to-blue-800/40 backdrop-blur-xl rounded-3xl p-12 border border-purple-500/30 max-w-md mx-auto">
              <div className="text-8xl mb-6 animate-float">🌌</div>
              <h3 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent mb-4">
                Empty Universe
              </h3>
              <p className="text-purple-200 mb-6">No cosmic transactions found in this dimension</p>
              <button 
                onClick={clearAllFilters}
                className="px-8 py-4 bg-gradient-to-r from-pink-500 to-purple-500 text-white rounded-2xl font-bold hover:shadow-lg hover:shadow-pink-500/30 transition-all"
              >
                🔄 Reset Filters
              </button>
            </div>
          </div>
        ) : viewMode === 'timeline' ? (
          <div className="space-y-6">
            {filteredRecharges.map((recharge, index) => (
              <div 
                key={recharge.id}
                className="relative animate-slide-right"
                style={{animationDelay: `${index * 0.1}s`}}
              >
                {/* Timeline Line */}
                {index < filteredRecharges.length - 1 && (
                  <div className="absolute left-8 top-20 w-0.5 h-16 bg-gradient-to-b from-purple-400 to-transparent"></div>
                )}
                
                <div className="flex items-start gap-6">
                  {/* Timeline Dot */}
                  <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex items-center justify-center shadow-lg shadow-purple-500/30 animate-pulse">
                    <span className="text-2xl">{getStatusIcon(recharge.status)}</span>
                  </div>
                  
                  {/* Transaction Card */}
                  <div 
                    className="flex-1 bg-gradient-to-br from-purple-800/40 to-blue-800/40 backdrop-blur-xl rounded-3xl p-6 border border-purple-500/30 hover:border-pink-400/50 transition-all cursor-pointer hover:scale-105"
                    onClick={() => setSelectedRecharge(recharge)}
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                      <div className="flex items-start gap-4 mb-4 lg:mb-0">
                        <OperatorLogo operator={recharge.operator} size="lg" />
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            <h3 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                              ₹{recharge.amount}
                            </h3>
                            <span className={`px-4 py-2 rounded-full text-sm font-bold ${getStatusBadge(recharge.status)}`}>
                              {getStatusIcon(recharge.status)} {recharge.status?.toUpperCase()}
                            </span>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <span className="text-purple-300">📱</span>
                              <span className="text-white font-mono bg-purple-900/50 px-3 py-1 rounded-lg">
                                {recharge.mobile}
                              </span>
                            </div>
                            
                            <div className="flex items-center gap-2">
                              <span className="text-purple-300">🎯</span>
                              <span className="text-purple-100">{recharge.planTitle}</span>
                            </div>
                            
                            <div className="flex items-center gap-2">
                              <span className="text-purple-300">⏰</span>
                              <span className="text-purple-100">{recharge.planValidity}</span>
                            </div>
                            
                            {user?.role === 'admin' && (
                              <div className="flex items-center gap-2">
                                <span className="text-purple-300">👤</span>
                                <span className="text-purple-100">{recharge.employee}</span>
                              </div>
                            )}
                            
                            <div className="flex items-center gap-2">
                              <span className="text-purple-300">📅</span>
                              <span className="text-purple-100">
                                {new Date(recharge.date).toLocaleDateString('en-IN', {
                                  day: '2-digit',
                                  month: 'short',
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })}
                              </span>
                            </div>
                            
                            <div className="flex items-center gap-2">
                              <span className="text-purple-300">🆔</span>
                              <span className="text-purple-100 font-mono text-xs">{recharge.id}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="text-purple-300 text-sm mb-1">Click to explore</div>
                        <div className="text-3xl animate-bounce">🔍</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRecharges.map((recharge, index) => (
              <div 
                key={recharge.id}
                className="bg-gradient-to-br from-purple-800/40 to-blue-800/40 backdrop-blur-xl rounded-3xl p-6 border border-purple-500/30 hover:border-pink-400/50 transition-all cursor-pointer hover:scale-105 animate-slide-right"
                style={{animationDelay: `${index * 0.1}s`}}
                onClick={() => setSelectedRecharge(recharge)}
              >
                <div className="text-center mb-4">
                  <OperatorLogo operator={recharge.operator} size="lg" />
                  <div className="mt-3">
                    <div className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                      ₹{recharge.amount}
                    </div>
                    <div className={`inline-block px-3 py-1 rounded-full text-xs font-bold mt-2 ${getStatusBadge(recharge.status)}`}>
                      {getStatusIcon(recharge.status)} {recharge.status}
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-purple-300">📱 Mobile:</span>
                    <span className="text-white font-mono">{recharge.mobile}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-300">🎯 Plan:</span>
                    <span className="text-purple-100">{recharge.planTitle}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-300">📅 Date:</span>
                    <span className="text-purple-100">
                      {new Date(recharge.date).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          // Table View
          <div className="bg-gradient-to-br from-purple-800/40 to-blue-800/40 backdrop-blur-xl rounded-3xl border border-purple-500/30 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gradient-to-r from-purple-900/50 to-blue-900/50">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-bold text-purple-200">Status</th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-purple-200">Mobile</th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-purple-200">Amount</th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-purple-200">Operator</th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-purple-200">Plan</th>
                    {user?.role === 'admin' && (
                      <th className="px-6 py-4 text-left text-sm font-bold text-purple-200">Employee</th>
                    )}
                    <th className="px-6 py-4 text-left text-sm font-bold text-purple-200">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-purple-500/20">
                  {filteredRecharges.map((recharge) => (
                    <tr 
                      key={recharge.id} 
                      className="hover:bg-purple-800/20 cursor-pointer transition-all"
                      onClick={() => setSelectedRecharge(recharge)}
                    >
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${getStatusBadge(recharge.status)}`}>
                          {getStatusIcon(recharge.status)} {recharge.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-white font-mono">{recharge.mobile}</td>
                      <td className="px-6 py-4 text-2xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">₹{recharge.amount}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <OperatorLogo operator={recharge.operator} size="sm" />
                          <span className="text-white">{recharge.operator}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-purple-100">{recharge.planTitle}</td>
                      {user?.role === 'admin' && (
                        <td className="px-6 py-4 text-purple-100">{recharge.employee}</td>
                      )}
                      <td className="px-6 py-4 text-purple-100 text-sm">
                        {new Date(recharge.date).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {/* Footer */}
        <div className="mt-12 text-center">
          <div className="bg-gradient-to-r from-purple-800/40 to-blue-800/40 backdrop-blur-xl rounded-2xl p-6 border border-purple-500/30 inline-block">
            <div className="text-purple-200">
              Displaying <span className="text-pink-400 font-bold">{filteredRecharges.length}</span> of{' '}
              <span className="text-cyan-400 font-bold">{recharges.length}</span> cosmic transactions
              {(searchTerm || statusFilter !== 'all' || dateFilter !== 'all' || operatorFilter !== 'all') && (
                <span className="ml-4">
                  • <button 
                    onClick={clearAllFilters}
                    className="text-pink-400 hover:text-pink-300 underline transition-colors font-semibold"
                  >
                    🔄 Reset Universe
                  </button>
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedRecharge && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50" onClick={() => setSelectedRecharge(null)}>
          <div className="bg-gradient-to-br from-purple-800/90 to-blue-800/90 backdrop-blur-xl rounded-3xl p-8 border border-purple-500/50 max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-slide-right" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-start mb-6">
              <h3 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                🌟 Transaction Details
              </h3>
              <button 
                onClick={() => setSelectedRecharge(null)} 
                className="text-purple-300 hover:text-white text-3xl transition-colors"
              >
                ×
              </button>
            </div>
            
            <div className="space-y-6">
              <div className="text-center mb-6">
                <OperatorLogo operator={selectedRecharge.operator} size="xl" />
                <div className="mt-4">
                  <div className="text-5xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                    ₹{selectedRecharge.amount}
                  </div>
                  <div className={`inline-block px-4 py-2 rounded-full text-sm font-bold mt-3 ${getStatusBadge(selectedRecharge.status)}`}>
                    {getStatusIcon(selectedRecharge.status)} {selectedRecharge.status?.toUpperCase()}
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { label: 'Transaction ID', value: selectedRecharge.id, icon: '🆔' },
                  { label: 'Mobile Number', value: selectedRecharge.mobile, icon: '📱' },
                  { label: 'Plan Title', value: selectedRecharge.planTitle, icon: '🎯' },
                  { label: 'Validity', value: selectedRecharge.planValidity, icon: '⏰' },
                  { label: 'Operator', value: selectedRecharge.operator, icon: '📡' },
                  { label: 'Date & Time', value: new Date(selectedRecharge.date).toLocaleString(), icon: '📅' }
                ].map(({ label, value, icon }) => (
                  <div key={label} className="bg-purple-900/30 rounded-2xl p-4 border border-purple-500/20">
                    <div className="text-purple-300 text-sm mb-1 flex items-center gap-2">
                      <span>{icon}</span> {label}
                    </div>
                    <div className="text-white font-semibold">{value}</div>
                  </div>
                ))}
                
                {user?.role === 'admin' && (
                  <div className="bg-purple-900/30 rounded-2xl p-4 border border-purple-500/20">
                    <div className="text-purple-300 text-sm mb-1 flex items-center gap-2">
                      <span>👤</span> Processed By
                    </div>
                    <div className="text-white font-semibold">{selectedRecharge.employee}</div>
                    <div className="text-purple-400 text-xs">ID: {selectedRecharge.employeeId}</div>
                  </div>
                )}
              </div>
              
              <div className="bg-purple-900/30 rounded-2xl p-4 border border-purple-500/20">
                <div className="text-purple-300 text-sm mb-2 flex items-center gap-2">
                  <span>📝</span> Plan Description
                </div>
                <div className="text-purple-100">{selectedRecharge.planDescription}</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}