import { useState, useEffect } from 'react'
import { getRecharges, getPlans } from '../api/api'
import { useAuth } from '../context/AuthContext'
import OperatorLogo from '../components/OperatorLogo'
import PaymentReceipt from '../components/PaymentReceipt'

export default function Dashboard() {
  const { user } = useAuth()
  const [recharges, setRecharges] = useState([])
  const [plans, setPlans] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedPeriod, setSelectedPeriod] = useState('week')
  const [showReceipt, setShowReceipt] = useState(false)
  const [selectedRecharge, setSelectedRecharge] = useState(null)

  useEffect(() => {
    Promise.all([getRecharges(), getPlans()])
      .then(([rechargeRes, planRes]) => {
        let data = rechargeRes.data || []
        if (user?.role === 'employee') {
          data = data.filter(r => r.employeeId === user.id)
        }
        setRecharges(data)
        setPlans(planRes.data || [])
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [user])

  const getFilteredData = () => {
    const now = new Date()
    const filterDate = new Date()
    
    switch(selectedPeriod) {
      case 'today':
        filterDate.setHours(0, 0, 0, 0)
        break
      case 'week':
        filterDate.setDate(now.getDate() - 7)
        break
      case 'month':
        filterDate.setMonth(now.getMonth() - 1)
        break
      case 'year':
        filterDate.setFullYear(now.getFullYear() - 1)
        break
      default:
        return recharges
    }
    
    return recharges.filter(r => new Date(r.date) >= filterDate)
  }

  const downloadReport = (format = 'csv') => {
    const filteredData = getFilteredData()
    
    if (format === 'csv') {
      const csvContent = [
        ['Date', 'Mobile', 'Amount', 'Plan ID', 'Operator', 'Employee', 'Status', 'Transaction ID'],
        ...filteredData.map(r => [
          new Date(r.date).toLocaleString(),
          r.mobile,
          r.amount,
          r.planId,
          r.operator || 'N/A',
          r.employee,
          r.status,
          r.id
        ])
      ].map(row => row.join(',')).join('\n')
      
      const blob = new Blob([csvContent], { type: 'text/csv' })
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `QuickTopUp-Report-${selectedPeriod}-${new Date().toISOString().split('T')[0]}.csv`
      a.click()
    } else if (format === 'json') {
      const jsonContent = JSON.stringify(filteredData, null, 2)
      const blob = new Blob([jsonContent], { type: 'application/json' })
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `QuickTopUp-Report-${selectedPeriod}-${new Date().toISOString().split('T')[0]}.json`
      a.click()
    }
  }

  const filteredData = getFilteredData()
  const stats = {
    total: filteredData.length,
    success: filteredData.filter(r => r.status === 'success').length,
    failed: filteredData.filter(r => r.status === 'failed').length,
    pending: filteredData.filter(r => r.status === 'pending').length,
    totalAmount: filteredData.reduce((sum, r) => sum + (r.amount || 0), 0),
    avgAmount: filteredData.length ? Math.round(filteredData.reduce((sum, r) => sum + (r.amount || 0), 0) / filteredData.length) : 0
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 border-4 border-indigo-300 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
          <div className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
            Loading Dashboard...
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-800/40 to-purple-800/40 backdrop-blur-xl border-b border-indigo-500/30 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div className="mb-6 lg:mb-0">
              <h1 className="text-5xl font-black bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
                📊 {user?.role === 'admin' ? 'Admin Dashboard' : 'My Dashboard'}
              </h1>
              <p className="text-xl text-indigo-200">
                {user?.role === 'admin' ? 'Complete system overview and analytics' : `Welcome back, ${user?.name}!`}
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <select
                className="px-4 py-3 bg-indigo-900/50 border border-indigo-400/30 rounded-2xl text-white focus:border-pink-400 transition-all"
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
              >
                <option value="today">📅 Today</option>
                <option value="week">📅 This Week</option>
                <option value="month">📅 This Month</option>
                <option value="year">📅 This Year</option>
                <option value="all">📅 All Time</option>
              </select>
              
              <div className="flex gap-2">
                <button
                  onClick={() => downloadReport('csv')}
                  className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-2xl font-bold hover:scale-105 transition-all"
                >
                  📊 CSV
                </button>
                <button
                  onClick={() => downloadReport('json')}
                  className="px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-2xl font-bold hover:scale-105 transition-all"
                >
                  📄 JSON
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl rounded-3xl p-6 border border-blue-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-3 animate-bounce">📊</div>
            <div className="text-3xl font-bold text-cyan-300">{stats.total}</div>
            <div className="text-sm text-cyan-200">Total</div>
          </div>
          
          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl rounded-3xl p-6 border border-green-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-3 animate-pulse">✅</div>
            <div className="text-3xl font-bold text-emerald-300">{stats.success}</div>
            <div className="text-sm text-emerald-200">Success</div>
          </div>
          
          <div className="bg-gradient-to-br from-red-500/20 to-pink-500/20 backdrop-blur-xl rounded-3xl p-6 border border-red-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-3 animate-bounce">❌</div>
            <div className="text-3xl font-bold text-red-300">{stats.failed}</div>
            <div className="text-sm text-red-200">Failed</div>
          </div>
          
          <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 backdrop-blur-xl rounded-3xl p-6 border border-yellow-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-3 animate-spin">⏳</div>
            <div className="text-3xl font-bold text-yellow-300">{stats.pending}</div>
            <div className="text-sm text-yellow-200">Pending</div>
          </div>
          
          <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-xl rounded-3xl p-6 border border-purple-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-3 animate-float">💰</div>
            <div className="text-2xl font-bold text-purple-300">₹{stats.totalAmount}</div>
            <div className="text-sm text-purple-200">Revenue</div>
          </div>
          
          <div className="bg-gradient-to-br from-indigo-500/20 to-blue-500/20 backdrop-blur-xl rounded-3xl p-6 border border-indigo-400/30 text-center hover:scale-105 transition-all">
            <div className="text-4xl mb-3 animate-pulse">📈</div>
            <div className="text-2xl font-bold text-indigo-300">₹{stats.avgAmount}</div>
            <div className="text-sm text-indigo-200">Average</div>
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="bg-gradient-to-br from-indigo-800/40 to-purple-800/40 backdrop-blur-xl rounded-3xl p-8 border border-indigo-500/30 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl font-bold text-indigo-300">🕒 Recent Transactions</h2>
            <div className="text-sm text-indigo-200">
              Showing last {Math.min(5, filteredData.length)} transactions
            </div>
          </div>
          
          {filteredData.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4 animate-float">📭</div>
              <h3 className="text-2xl font-bold text-indigo-300 mb-2">No Transactions</h3>
              <p className="text-indigo-200">No transactions found for the selected period</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredData.slice(0, 5).map((recharge, index) => (
                <div
                  key={recharge.id}
                  className="bg-indigo-900/30 rounded-2xl p-6 border border-indigo-600/30 hover:bg-indigo-800/40 transition-all cursor-pointer animate-slide-right"
                  style={{ animationDelay: `${index * 0.1}s` }}
                  onClick={() => {
                    setSelectedRecharge(recharge)
                    setShowReceipt(true)
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <OperatorLogo operator={recharge.operator} size="md" />
                      <div>
                        <div className="flex items-center gap-3 mb-1">
                          <span className="text-2xl font-bold text-indigo-300">₹{recharge.amount}</span>
                          <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                            recharge.status === 'success' ? 'bg-green-500' :
                            recharge.status === 'failed' ? 'bg-red-500' : 'bg-yellow-500'
                          }`}>
                            {recharge.status?.toUpperCase()}
                          </span>
                        </div>
                        <div className="text-indigo-200 font-mono">{recharge.mobile}</div>
                        <div className="text-sm text-indigo-300">
                          {new Date(recharge.date).toLocaleString()}
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-indigo-300 text-sm mb-1">Click for receipt</div>
                      <div className="text-2xl animate-bounce">🧾</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl rounded-3xl p-6 border border-blue-400/30 text-center hover:scale-105 transition-all cursor-pointer">
            <div className="text-5xl mb-4 animate-bounce">📱</div>
            <h3 className="text-xl font-bold text-blue-300 mb-2">New Recharge</h3>
            <p className="text-blue-200 text-sm">Start a new mobile recharge</p>
          </div>
          
          <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-xl rounded-3xl p-6 border border-purple-400/30 text-center hover:scale-105 transition-all cursor-pointer">
            <div className="text-5xl mb-4 animate-pulse">📊</div>
            <h3 className="text-xl font-bold text-purple-300 mb-2">View Plans</h3>
            <p className="text-purple-200 text-sm">Browse available plans</p>
          </div>
          
          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl rounded-3xl p-6 border border-green-400/30 text-center hover:scale-105 transition-all cursor-pointer">
            <div className="text-5xl mb-4 animate-float">📈</div>
            <h3 className="text-xl font-bold text-green-300 mb-2">Analytics</h3>
            <p className="text-green-200 text-sm">View detailed reports</p>
          </div>
          
          <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-xl rounded-3xl p-6 border border-orange-400/30 text-center hover:scale-105 transition-all cursor-pointer">
            <div className="text-5xl mb-4 animate-spin">⚙️</div>
            <h3 className="text-xl font-bold text-orange-300 mb-2">Settings</h3>
            <p className="text-orange-200 text-sm">Manage preferences</p>
          </div>
        </div>
      </div>

      {/* Receipt Modal */}
      {showReceipt && selectedRecharge && (
        <PaymentReceipt 
          recharge={selectedRecharge} 
          onClose={() => {
            setShowReceipt(false)
            setSelectedRecharge(null)
          }} 
        />
      )}
    </div>
  )
}