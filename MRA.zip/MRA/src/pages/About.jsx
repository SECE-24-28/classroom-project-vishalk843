import { useState } from 'react'

export default function About() {
  const [activeTab, setActiveTab] = useState('story')

  const tabs = [
    { id: 'story', label: '📖 Our Story', icon: '📖' },
    { id: 'mission', label: '🎯 Mission', icon: '🎯' },
    { id: 'team', label: '👥 Team', icon: '👥' },
    { id: 'values', label: '💎 Values', icon: '💎' }
  ]

  const teamMembers = [
    { name: 'Alex Johnson', role: 'CEO & Founder', avatar: '👨‍💼', color: 'from-blue-500 to-cyan-500' },
    { name: 'Sarah Chen', role: 'CTO', avatar: '👩‍💻', color: 'from-purple-500 to-pink-500' },
    { name: 'Mike Rodriguez', role: 'Head of Operations', avatar: '👨‍🔧', color: 'from-green-500 to-emerald-500' },
    { name: 'Emily Davis', role: 'Head of Design', avatar: '👩‍🎨', color: 'from-orange-500 to-red-500' }
  ]

  const values = [
    { title: 'Innovation', desc: 'Constantly pushing boundaries in fintech', icon: '🚀', color: 'from-blue-400 to-purple-600' },
    { title: 'Trust', desc: 'Building lasting relationships through reliability', icon: '🤝', color: 'from-green-400 to-blue-600' },
    { title: 'Speed', desc: 'Lightning-fast transactions every time', icon: '⚡', color: 'from-yellow-400 to-orange-600' },
    { title: 'Security', desc: 'Your data and money are always protected', icon: '🛡️', color: 'from-red-400 to-pink-600' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-900 via-teal-900 to-cyan-900">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-72 h-72 bg-gradient-to-br from-emerald-400/20 to-teal-600/20 rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-gradient-to-br from-cyan-400/20 to-blue-600/20 rounded-full blur-3xl animate-float" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
          <div className="mb-8">
            <div className="text-8xl mb-6 animate-bounce">🌟</div>
            <h1 className="text-7xl font-black mb-6 bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 bg-clip-text text-transparent animate-glow">
              About QuickTopUp
            </h1>
            <p className="text-2xl text-emerald-200 max-w-3xl mx-auto leading-relaxed">
              Revolutionizing mobile recharges with cutting-edge technology and unmatched user experience
            </p>
          </div>
        </div>
      </section>

      {/* Tab Navigation */}
      <section className="py-12">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-8 py-4 rounded-2xl font-bold text-lg transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-2xl shadow-emerald-500/30 scale-110'
                    : 'bg-emerald-800/30 text-emerald-300 hover:bg-emerald-700/40 backdrop-blur-sm border border-emerald-600/30'
                }`}
              >
                {tab.icon} {tab.label}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="bg-gradient-to-br from-emerald-800/40 to-teal-800/40 backdrop-blur-xl rounded-3xl p-12 border border-emerald-500/30 shadow-2xl">
            {activeTab === 'story' && (
              <div className="animate-slide-right">
                <h2 className="text-4xl font-bold text-emerald-300 mb-8 text-center">📖 Our Journey</h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                  <div className="space-y-6">
                    <div className="bg-emerald-900/50 rounded-2xl p-6 border border-emerald-600/30">
                      <h3 className="text-2xl font-bold text-emerald-300 mb-3">🌱 The Beginning (2020)</h3>
                      <p className="text-emerald-100">
                        Started as a small startup with a big dream - to make mobile recharges as simple as sending a text message.
                      </p>
                    </div>
                    <div className="bg-emerald-900/50 rounded-2xl p-6 border border-emerald-600/30">
                      <h3 className="text-2xl font-bold text-emerald-300 mb-3">🚀 Growth (2021-2022)</h3>
                      <p className="text-emerald-100">
                        Expanded to support all major operators and introduced innovative features like instant recharges and smart recommendations.
                      </p>
                    </div>
                    <div className="bg-emerald-900/50 rounded-2xl p-6 border border-emerald-600/30">
                      <h3 className="text-2xl font-bold text-emerald-300 mb-3">🏆 Today (2024)</h3>
                      <p className="text-emerald-100">
                        Serving millions of users across the country with 99.9% uptime and industry-leading security standards.
                      </p>
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-9xl mb-6 animate-float">📱</div>
                    <div className="bg-gradient-to-r from-emerald-500/20 to-teal-500/20 rounded-3xl p-8 border border-emerald-400/30">
                      <div className="text-5xl font-bold text-emerald-300 mb-2">50M+</div>
                      <div className="text-emerald-200">Successful Recharges</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'mission' && (
              <div className="animate-slide-left">
                <h2 className="text-4xl font-bold text-emerald-300 mb-8 text-center">🎯 Our Mission</h2>
                <div className="text-center mb-12">
                  <div className="text-8xl mb-6 animate-pulse">🌍</div>
                  <p className="text-2xl text-emerald-100 max-w-4xl mx-auto leading-relaxed mb-8">
                    "To democratize digital payments and make mobile recharges accessible, instant, and secure for everyone, everywhere."
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="text-center bg-emerald-900/50 rounded-2xl p-8 border border-emerald-600/30">
                    <div className="text-5xl mb-4 animate-bounce">🎯</div>
                    <h3 className="text-xl font-bold text-emerald-300 mb-3">Accessibility</h3>
                    <p className="text-emerald-100">Making recharges available to everyone, regardless of location or device.</p>
                  </div>
                  <div className="text-center bg-emerald-900/50 rounded-2xl p-8 border border-emerald-600/30">
                    <div className="text-5xl mb-4 animate-pulse">⚡</div>
                    <h3 className="text-xl font-bold text-emerald-300 mb-3">Speed</h3>
                    <p className="text-emerald-100">Instant transactions that complete in seconds, not minutes.</p>
                  </div>
                  <div className="text-center bg-emerald-900/50 rounded-2xl p-8 border border-emerald-600/30">
                    <div className="text-5xl mb-4 animate-spin">🔒</div>
                    <h3 className="text-xl font-bold text-emerald-300 mb-3">Security</h3>
                    <p className="text-emerald-100">Bank-grade security protecting every transaction and user data.</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'team' && (
              <div className="animate-slide-right">
                <h2 className="text-4xl font-bold text-emerald-300 mb-8 text-center">👥 Meet Our Team</h2>
                <p className="text-xl text-emerald-200 text-center mb-12 max-w-3xl mx-auto">
                  Our diverse team of experts is passionate about creating the best mobile recharge experience
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {teamMembers.map((member, index) => (
                    <div
                      key={member.name}
                      className="text-center bg-emerald-900/50 rounded-3xl p-8 border border-emerald-600/30 hover:scale-105 transition-all animate-slide-right"
                      style={{ animationDelay: `${index * 0.2}s` }}
                    >
                      <div className={`w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-r ${member.color} flex items-center justify-center text-4xl animate-float`}>
                        {member.avatar}
                      </div>
                      <h3 className="text-xl font-bold text-emerald-300 mb-2">{member.name}</h3>
                      <p className="text-emerald-200">{member.role}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'values' && (
              <div className="animate-slide-left">
                <h2 className="text-4xl font-bold text-emerald-300 mb-8 text-center">💎 Our Core Values</h2>
                <p className="text-xl text-emerald-200 text-center mb-12 max-w-3xl mx-auto">
                  These principles guide everything we do and shape our company culture
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {values.map((value, index) => (
                    <div
                      key={value.title}
                      className="bg-emerald-900/50 rounded-3xl p-8 border border-emerald-600/30 hover:scale-105 transition-all animate-slide-right"
                      style={{ animationDelay: `${index * 0.2}s` }}
                    >
                      <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${value.color} flex items-center justify-center text-3xl mb-6 animate-float`}>
                        {value.icon}
                      </div>
                      <h3 className="text-2xl font-bold text-emerald-300 mb-4">{value.title}</h3>
                      <p className="text-emerald-100 text-lg">{value.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Awards Section */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-5xl font-bold text-center mb-16 bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
            🏆 Recognition & Awards
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { award: 'Best Fintech App 2024', org: 'Tech Innovation Awards', icon: '🥇' },
              { award: 'Customer Choice Award', org: 'Digital India Summit', icon: '🏆' },
              { award: 'Security Excellence', org: 'Cyber Security Council', icon: '🛡️' }
            ].map((award, index) => (
              <div
                key={award.award}
                className="text-center bg-gradient-to-br from-emerald-800/40 to-teal-800/40 backdrop-blur-xl rounded-3xl p-8 border border-emerald-500/30 hover:scale-105 transition-all animate-slide-right"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="text-6xl mb-4 animate-bounce">{award.icon}</div>
                <h3 className="text-xl font-bold text-emerald-300 mb-2">{award.award}</h3>
                <p className="text-emerald-200">{award.org}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}