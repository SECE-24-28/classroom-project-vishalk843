import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function EmployeeLogin(){
  const [username,setUsername]=useState('employee')
  const [password,setPassword]=useState('emp123')
  const { login } = useAuth()
  const nav = useNavigate()

  const submit = (e) => {
    e.preventDefault()
    // Demo login
    if(username==='employee' && password==='emp123'){
      login({ id: 'emp1', name: 'Employee One', role: 'employee' })
      nav('/employee/dashboard')
    } else alert('Invalid employee credentials')
  }

  return (
    <div className="flex items-center justify-center py-20">
      <form onSubmit={submit} className="bg-[#071226] card w-full max-w-md">
        <h2 className="text-xl font-bold mb-4">Employee Login</h2>
        <input className="w-full p-3 rounded mb-3 bg-transparent border border-gray-700" value={username} onChange={e=>setUsername(e.target.value)} />
        <input type="password" className="w-full p-3 rounded mb-3 bg-transparent border border-gray-700" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="btn-primary w-full">Login</button>
      </form>
    </div>
  )
}
