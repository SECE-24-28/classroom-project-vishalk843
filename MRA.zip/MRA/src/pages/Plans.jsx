import { useEffect, useState } from 'react'
import { getPlans } from '../api/api'
import { Link } from 'react-router-dom'
import OperatorLogo from '../components/OperatorLogo'

export default function Plans(){
  const [plans, setPlans] = useState([])
  const [filteredPlans, setFilteredPlans] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedOperator, setSelectedOperator] = useState('all')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [priceRange, setPriceRange] = useState('all')
  const [sortBy, setSortBy] = useState('price')

  useEffect(() => { 
    getPlans()
      .then(r => { 
        const planData = r.data || []
        setPlans(planData)
        setFilteredPlans(planData)
        setLoading(false) 
      })
      .catch(err => { 
        console.error('Error loading plans:', err); 
        setPlans([])
        setFilteredPlans([])
        setLoading(false); 
      }) 
  }, [])

  useEffect(() => {
    let filtered = [...plans]
    
    if (selectedOperator !== 'all') {
      filtered = filtered.filter(plan => plan.operator === selectedOperator)
    }
    
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(plan => plan.category === selectedCategory)
    }
    
    if (priceRange !== 'all') {
      switch(priceRange) {
        case 'budget':
          filtered = filtered.filter(plan => plan.amount <= 100)
          break
        case 'mid':
          filtered = filtered.filter(plan => plan.amount > 100 && plan.amount <= 300)
          break
        case 'premium':
          filtered = filtered.filter(plan => plan.amount > 300)
          break
      }
    }
    
    filtered.sort((a, b) => {
      switch(sortBy) {
        case 'price':
          return a.amount - b.amount
        case 'validity':
          return parseInt(a.validity) - parseInt(b.validity)
        case 'operator':
          return a.operator?.localeCompare(b.operator)
        default:
          return 0
      }
    })
    
    setFilteredPlans(filtered)
  }, [plans, selectedOperator, selectedCategory, priceRange, sortBy])

  const getCategoryIcon = (category) => {
    switch(category) {
      case 'Data': return '📊'
      case 'Top-up': return '💰'
      case 'Voice': return '📞'
      default: return '📱'
    }
  }

  const operators = [...new Set(plans.map(p => p.operator).filter(Boolean))]
  const categories = [...new Set(plans.map(p => p.category).filter(Boolean))]

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 spinner mx-auto mb-4"></div>
        <p className="text-gray-300 text-lg">Loading amazing plans...</p>
      </div>
    </div>
  )

  if (plans.length === 0) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="card text-center max-w-md">
        <div className="text-6xl mb-4 animate-float">📱</div>
        <h2 className="text-2xl font-bold text-gradient mb-2">No Plans Available</h2>
        <p className="text-gray-400">Please check your connection or contact admin.</p>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#071226] via-[#081425] to-[#0a1628] p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="card mb-8 animate-slide-left">
          <div className="text-center mb-8">
            <h1 className="text-5xl font-bold text-gradient mb-4 animate-glow">
              📱 Mobile Recharge Plans
            </h1>
            <p className="text-gray-400 text-xl">
              Choose from premium plans across all major operators
            </p>
          </div>
          
          {/* Operator Showcase */}
          <div className="flex justify-center items-center gap-6 mb-8">
            {operators.map(op => (
              <div key={op} className="text-center">
                <OperatorLogo operator={op} size="lg" />
                <div className={`text-sm font-semibold mt-2 text-${op.toLowerCase()}`}>{op}</div>
              </div>
            ))}
          </div>
          
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <select
              className="input-field"
              value={selectedOperator}
              onChange={(e) => setSelectedOperator(e.target.value)}
            >
              <option value="all">🌐 All Operators</option>
              {operators.map(op => (
                <option key={op} value={op}>{op}</option>
              ))}
            </select>
            
            <select
              className="input-field"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="all">📋 All Categories</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{getCategoryIcon(cat)} {cat}</option>
              ))}
            </select>
            
            <select
              className="input-field"
              value={priceRange}
              onChange={(e) => setPriceRange(e.target.value)}
            >
              <option value="all">💰 All Prices</option>
              <option value="budget">💰 Budget (≤₹100)</option>
              <option value="mid">💰 Mid-range (₹100-300)</option>
              <option value="premium">💰 Premium (>₹300)</option>
            </select>
            
            <select
              className="input-field"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="price">📊 Sort by Price</option>
              <option value="validity">⏰ Sort by Validity</option>
              <option value="operator">🏢 Sort by Operator</option>
            </select>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="card bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20 text-center animate-slide-right">
            <div className="text-3xl mb-2 animate-float">📊</div>
            <div className="text-2xl font-bold text-white">{filteredPlans.length}</div>
            <div className="text-sm text-blue-400">Available Plans</div>
          </div>
          
          <div className="card bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 text-center animate-slide-right" style={{animationDelay: '0.1s'}}>
            <div className="text-3xl mb-2 animate-float">🏢</div>
            <div className="text-2xl font-bold text-white">{operators.length}</div>
            <div className="text-sm text-green-400">Operators</div>
          </div>
          
          <div className="card bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 text-center animate-slide-right" style={{animationDelay: '0.2s'}}>
            <div className="text-3xl mb-2 animate-float">💰</div>
            <div className="text-xl font-bold text-white">
              ₹{filteredPlans.length ? Math.min(...filteredPlans.map(p => p.amount)) : 0}
            </div>
            <div className="text-sm text-purple-400">Starting From</div>
          </div>
          
          <div className="card bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/20 text-center animate-slide-right" style={{animationDelay: '0.3s'}}>
            <div className="text-3xl mb-2 animate-float">📱</div>
            <div className="text-2xl font-bold text-white">{categories.length}</div>
            <div className="text-sm text-yellow-400">Categories</div>
          </div>
        </div>

        {/* Plans Grid */}
        {filteredPlans.length === 0 ? (
          <div className="text-center py-20">
            <div className="card max-w-md mx-auto">
              <div className="text-6xl mb-6 animate-float">🔍</div>
              <h3 className="text-2xl font-bold text-gradient mb-4">No Plans Found</h3>
              <p className="text-gray-400 mb-6">Try adjusting your filters to see more plans</p>
              <button 
                onClick={() => {
                  setSelectedOperator('all')
                  setSelectedCategory('all')
                  setPriceRange('all')
                }}
                className="btn-primary"
              >
                🔄 Clear Filters
              </button>
            </div>
          </div>
        ) : (
          <div className="grid-responsive">
            {filteredPlans.map((plan, index) => (
              <div 
                key={plan.id} 
                className="card card-hover animate-slide-right"
                style={{animationDelay: `${index * 0.1}s`}}
              >
                {/* Plan Header */}
                <div className="flex justify-between items-start mb-6">
                  <OperatorLogo operator={plan.operator} size="md" />
                  <div className="text-right">
                    <div className="text-xs text-gray-400 bg-gray-800/50 px-3 py-1 rounded-full">
                      {getCategoryIcon(plan.category)} {plan.category}
                    </div>
                  </div>
                </div>
                
                {/* Price Section */}
                <div className="text-center mb-6">
                  <div className="text-4xl font-bold text-gradient mb-2">₹{plan.amount}</div>
                  <h3 className="text-xl font-bold text-white mb-1">{plan.title}</h3>
                  <p className="text-gray-400">⏰ Valid for {plan.validity}</p>
                </div>
                
                {/* Plan Description */}
                <div className="mb-6">
                  <p className="text-gray-300 text-center mb-4">{plan.description}</p>
                  
                  {/* Benefits */}
                  {plan.benefits && (
                    <div className="space-y-2">
                      <div className="text-sm font-semibold text-gray-400 mb-2">✨ Benefits:</div>
                      {plan.benefits.slice(0, 3).map((benefit, idx) => (
                        <div key={idx} className="flex items-center text-sm text-gray-300">
                          <span className="text-green-400 mr-2 text-xs">✓</span>
                          {benefit}
                        </div>
                      ))}
                      {plan.benefits.length > 3 && (
                        <div className="text-xs text-gray-500">
                          +{plan.benefits.length - 3} more benefits
                        </div>
                      )}
                    </div>
                  )}
                </div>
                
                {/* Recharge Button */}
                <Link 
                  to={`/recharge/${plan.id}`} 
                  state={plan} 
                  className="btn-primary w-full text-center block"
                >
                  🚀 Recharge Now
                </Link>
                
                {/* Popular Badge */}
                {plan.amount >= 199 && plan.amount <= 299 && (
                  <div className="absolute -top-3 -right-3 bg-gradient-to-r from-yellow-500 to-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg animate-pulse">
                    🔥 Popular
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
        
        {/* Footer */}
        <div className="mt-12 text-center">
          <div className="card inline-block">
            <div className="text-sm text-gray-400">
              Showing <span className="text-gradient font-semibold">{filteredPlans.length}</span> of{' '}
              <span className="text-gradient font-semibold">{plans.length}</span> plans
              {(selectedOperator !== 'all' || selectedCategory !== 'all' || priceRange !== 'all') && (
                <span className="ml-4">
                  • <button 
                    onClick={() => {
                      setSelectedOperator('all')
                      setSelectedCategory('all')
                      setPriceRange('all')
                    }}
                    className="text-blue-400 hover:text-blue-300 underline transition-colors"
                  >
                    Clear filters
                  </button>
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}