import { useState, useEffect } from 'react'

export default function DataStatus() {
  const [data, setData] = useState({ plans: 0, recharges: 0 })
  
  useEffect(() => {
    const updateData = () => {
      try {
        const plans = JSON.parse(localStorage.getItem('qt_plans') || '[]')
        const recharges = JSON.parse(localStorage.getItem('qt_recharges') || '[]')
        setData({ plans: plans.length, recharges: recharges.length })
      } catch (e) {
        setData({ plans: 0, recharges: 0 })
      }
    }
    
    updateData()
    const interval = setInterval(updateData, 1000)
    return () => clearInterval(interval)
  }, [])
  
  return (
    <div className="fixed bottom-4 left-4 bg-gray-800 text-white p-2 rounded text-xs">
      Plans: {data.plans} | Recharges: {data.recharges}
    </div>
  )
}