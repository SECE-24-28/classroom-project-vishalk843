import { useState } from 'react'
import OperatorLogo from './OperatorLogo'

export default function PaymentReceipt({ recharge, onClose }) {
  const [downloading, setDownloading] = useState(false)

  const generateReceiptHTML = () => {
    return `
    <!DOCTYPE html>
    <html>
    <head>
        <title>QuickTopUp Receipt</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
            .receipt { max-width: 400px; margin: 0 auto; background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
            .header { background: linear-gradient(135deg, #7c3aed, #06b6d4); color: white; padding: 30px 20px; text-align: center; }
            .logo { font-size: 24px; font-weight: bold; margin-bottom: 10px; }
            .content { padding: 30px 20px; }
            .row { display: flex; justify-content: space-between; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid #eee; }
            .label { color: #666; font-size: 14px; }
            .value { font-weight: bold; color: #333; }
            .amount { font-size: 28px; color: #7c3aed; font-weight: bold; text-align: center; margin: 20px 0; }
            .status { text-align: center; padding: 10px; background: #d4edda; color: #155724; border-radius: 8px; margin: 20px 0; }
            .footer { text-align: center; color: #666; font-size: 12px; margin-top: 30px; }
            .qr-placeholder { width: 80px; height: 80px; background: #f0f0f0; margin: 20px auto; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #999; }
        </style>
    </head>
    <body>
        <div class="receipt">
            <div class="header">
                <div class="logo">📱 QuickTopUp</div>
                <div>Payment Receipt</div>
            </div>
            <div class="content">
                <div class="status">✅ Transaction Successful</div>
                
                <div class="amount">₹${recharge.amount}</div>
                
                <div class="row">
                    <span class="label">Transaction ID</span>
                    <span class="value">${recharge.id}</span>
                </div>
                
                <div class="row">
                    <span class="label">Mobile Number</span>
                    <span class="value">${recharge.mobile}</span>
                </div>
                
                <div class="row">
                    <span class="label">Operator</span>
                    <span class="value">${recharge.operator || 'N/A'}</span>
                </div>
                
                <div class="row">
                    <span class="label">Plan</span>
                    <span class="value">${recharge.planTitle || 'N/A'}</span>
                </div>
                
                <div class="row">
                    <span class="label">Date & Time</span>
                    <span class="value">${new Date(recharge.date).toLocaleString()}</span>
                </div>
                
                <div class="row">
                    <span class="label">Processed By</span>
                    <span class="value">${recharge.employee}</span>
                </div>
                
                <div class="row">
                    <span class="label">Payment Method</span>
                    <span class="value">Digital Wallet</span>
                </div>
                
                <div class="row">
                    <span class="label">Service Charge</span>
                    <span class="value">₹0.00</span>
                </div>
                
                <div class="qr-placeholder">
                    QR Code
                </div>
                
                <div class="footer">
                    <p>Thank you for using QuickTopUp!</p>
                    <p>For support: support@quicktopup.com | 1800-123-4567</p>
                    <p>Generated on ${new Date().toLocaleString()}</p>
                </div>
            </div>
        </div>
    </body>
    </html>
    `
  }

  const downloadReceipt = async () => {
    setDownloading(true)
    try {
      const receiptHTML = generateReceiptHTML()
      const blob = new Blob([receiptHTML], { type: 'text/html' })
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `QuickTopUp-Receipt-${recharge.id}.html`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Download failed:', error)
    }
    setDownloading(false)
  }

  const printReceipt = () => {
    const receiptHTML = generateReceiptHTML()
    const printWindow = window.open('', '_blank')
    printWindow.document.write(receiptHTML)
    printWindow.document.close()
    printWindow.print()
  }

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50 backdrop-blur-sm" onClick={onClose}>
      <div className="card max-w-md w-full animate-slide-right" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-neon to-neon2 rounded-full flex items-center justify-center animate-glow">
            <span className="text-2xl">🧾</span>
          </div>
          <h3 className="text-2xl font-bold text-gradient">Payment Receipt</h3>
          <p className="text-gray-400">Transaction Details</p>
        </div>

        {/* Receipt Content */}
        <div className="space-y-4 mb-6">
          {/* Status */}
          <div className="text-center">
            <div className="status-success inline-flex items-center gap-2 px-4 py-2 text-sm">
              ✅ Transaction Successful
            </div>
          </div>

          {/* Amount */}
          <div className="text-center py-4 bg-gradient-to-r from-neon/10 to-neon2/10 rounded-2xl border border-neon/20">
            <div className="text-4xl font-bold text-gradient">₹{recharge.amount}</div>
            <div className="text-gray-400 text-sm">Amount Paid</div>
          </div>

          {/* Transaction Details */}
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
              <span className="text-gray-400">Transaction ID</span>
              <span className="text-white font-mono text-sm">{recharge.id}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
              <span className="text-gray-400">Mobile Number</span>
              <span className="text-white font-mono">{recharge.mobile}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
              <span className="text-gray-400">Operator</span>
              <div className="flex items-center gap-2">
                <OperatorLogo operator={recharge.operator} size="sm" />
                <span className="text-white">{recharge.operator || 'N/A'}</span>
              </div>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
              <span className="text-gray-400">Plan</span>
              <span className="text-white">{recharge.planTitle || 'N/A'}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
              <span className="text-gray-400">Date & Time</span>
              <span className="text-white text-sm">{new Date(recharge.date).toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
              <span className="text-gray-400">Processed By</span>
              <span className="text-white">{recharge.employee}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
              <span className="text-gray-400">Payment Method</span>
              <span className="text-white">💳 Digital Wallet</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-xl">
              <span className="text-gray-400">Service Charge</span>
              <span className="text-green-400">₹0.00 (Free)</span>
            </div>
          </div>

          {/* QR Code Placeholder */}
          <div className="text-center py-4">
            <div className="w-20 h-20 mx-auto bg-gray-800 rounded-xl flex items-center justify-center mb-2">
              <span className="text-2xl">📱</span>
            </div>
            <p className="text-xs text-gray-500">Scan for digital receipt</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 mb-4">
          <button
            onClick={downloadReceipt}
            disabled={downloading}
            className="flex-1 btn-success flex items-center justify-center gap-2"
          >
            {downloading ? (
              <>
                <div className="w-4 h-4 spinner"></div>
                Downloading...
              </>
            ) : (
              <>
                📥 Download
              </>
            )}
          </button>
          
          <button
            onClick={printReceipt}
            className="flex-1 btn-secondary flex items-center justify-center gap-2"
          >
            🖨️ Print
          </button>
        </div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="w-full btn-secondary"
        >
          Close Receipt
        </button>

        {/* Footer */}
        <div className="text-center mt-4 text-xs text-gray-500">
          <p>Thank you for using QuickTopUp! 🚀</p>
          <p>For support: support@quicktopup.com</p>
        </div>
      </div>
    </div>
  )
}