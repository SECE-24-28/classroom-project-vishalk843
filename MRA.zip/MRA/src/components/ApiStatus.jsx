import { useState, useEffect } from 'react'
import { getPlans } from '../api/api'

export default function ApiStatus() {
  const [status, setStatus] = useState('checking')
  const [apiType, setApiType] = useState('unknown')

  useEffect(() => {
    checkApiStatus()
  }, [])

  const checkApiStatus = async () => {
    try {
      const response = await getPlans()
      if (response.data) {
        // Check if we're using MockAPI or localStorage
        const isLocalStorage = localStorage.getItem('qt_plans')
        setApiType(isLocalStorage ? 'localStorage' : 'MockAPI')
        setStatus('connected')
      }
    } catch (error) {
      setStatus('error')
      setApiType('error')
    }
  }

  const getStatusColor = () => {
    switch (status) {
      case 'connected': return apiType === 'MockAPI' ? 'bg-green-600' : 'bg-blue-600'
      case 'error': return 'bg-red-600'
      default: return 'bg-yellow-600'
    }
  }

  const getStatusText = () => {
    switch (status) {
      case 'connected': return `Connected (${apiType})`
      case 'error': return 'Connection Error'
      default: return 'Checking...'
    }
  }

  const getStatusIcon = () => {
    switch (status) {
      case 'connected': return apiType === 'MockAPI' ? '🌐' : '💾'
      case 'error': return '❌'
      default: return '⏳'
    }
  }

  return (
    <div className="fixed top-4 right-4 z-50">
      <div className={`${getStatusColor()} text-white px-3 py-2 rounded-lg text-xs flex items-center gap-2 shadow-lg`}>
        <span>{getStatusIcon()}</span>
        <span>{getStatusText()}</span>
        {status === 'connected' && (
          <button 
            onClick={checkApiStatus}
            className="ml-2 hover:bg-white/20 rounded px-1"
            title="Refresh status"
          >
            🔄
          </button>
        )}
      </div>
    </div>
  )
}