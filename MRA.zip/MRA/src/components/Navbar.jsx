import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useState } from 'react'

export default function Navbar(){
  const { user, logout } = useAuth()
  const location = useLocation()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const isActive = (path) => location.pathname === path

  const navLinks = [
    { path: '/', label: 'Home', icon: '🏠' },
    { path: '/plans', label: 'Plans', icon: '📱' },
    { path: '/services', label: 'Services', icon: '🛠️' },
    { path: '/about', label: 'About', icon: '📖' },
  ]

  const userLinks = user ? [
    { path: '/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/history', label: 'History', icon: '📋' },
  ] : []

  return (
    <nav className="bg-white/95 backdrop-blur-xl border-b border-gray-200 sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 via-pink-500 to-indigo-500 flex items-center justify-center text-white font-bold text-xl shadow-lg group-hover:scale-110 transition-all animate-glow">
              QT
            </div>
            <div className="text-2xl font-black text-gradient">
              QuickTopUp
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {/* Main Navigation */}
            <div className="flex items-center gap-6">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition-all ${
                    isActive(link.path)
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                      : 'text-gray-700 hover:text-purple-600 hover:bg-purple-50'
                  }`}
                >
                  <span>{link.icon}</span>
                  {link.label}
                </Link>
              ))}
            </div>

            {/* User Navigation */}
            {user && (
              <div className="flex items-center gap-6 border-l border-gray-200 pl-6">
                {userLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition-all ${
                      isActive(link.path)
                        ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-lg'
                        : 'text-gray-700 hover:text-blue-600 hover:bg-blue-50'
                    }`}
                  >
                    <span>{link.icon}</span>
                    {link.label}
                  </Link>
                ))}
              </div>
            )}

            {/* User Menu */}
            <div className="flex items-center gap-4 border-l border-gray-200 pl-6">
              {user ? (
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-gray-800 font-semibold">👋 {user.name}</div>
                    <div className="text-xs text-purple-600 capitalize font-medium">{user.role}</div>
                  </div>
                  
                  <div className="flex gap-2">
                    {user.role === 'admin' ? (
                      <Link
                        to="/admin/dashboard"
                        className="px-4 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl font-semibold hover:scale-105 transition-all shadow-lg"
                      >
                        👑 Admin
                      </Link>
                    ) : (
                      <Link
                        to="/employee/dashboard"
                        className="px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-semibold hover:scale-105 transition-all shadow-lg"
                      >
                        👤 Employee
                      </Link>
                    )}
                    
                    <button
                      onClick={logout}
                      className="px-4 py-2 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-xl font-semibold hover:scale-105 transition-all shadow-lg"
                    >
                      🚪 Logout
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex gap-3">
                  <Link
                    to="/admin-login"
                    className="px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-semibold hover:scale-105 transition-all shadow-lg"
                  >
                    👑 Admin Login
                  </Link>
                  <Link
                    to="/employee-login"
                    className="px-6 py-2 bg-gradient-to-r from-green-500 to-teal-500 text-white rounded-xl font-semibold hover:scale-105 transition-all shadow-lg"
                  >
                    👤 Employee Login
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 text-gray-700 hover:bg-purple-50 rounded-xl transition-all"
          >
            <div className="w-6 h-6 flex flex-col justify-center items-center">
              <span className={`block w-5 h-0.5 bg-gray-700 transition-all ${isMenuOpen ? 'rotate-45 translate-y-1' : ''}`}></span>
              <span className={`block w-5 h-0.5 bg-gray-700 mt-1 transition-all ${isMenuOpen ? 'opacity-0' : ''}`}></span>
              <span className={`block w-5 h-0.5 bg-gray-700 mt-1 transition-all ${isMenuOpen ? '-rotate-45 -translate-y-1' : ''}`}></span>
            </div>
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden py-6 border-t border-gray-200 animate-slide-right bg-white">
            <div className="space-y-4">
              {/* Main Navigation */}
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all ${
                    isActive(link.path)
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                      : 'text-gray-700 hover:text-purple-600 hover:bg-purple-50'
                  }`}
                >
                  <span className="text-xl">{link.icon}</span>
                  {link.label}
                </Link>
              ))}

              {/* User Navigation */}
              {user && (
                <>
                  <div className="border-t border-gray-200 pt-4 mt-4">
                    {userLinks.map((link) => (
                      <Link
                        key={link.path}
                        to={link.path}
                        onClick={() => setIsMenuOpen(false)}
                        className={`flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all mb-2 ${
                          isActive(link.path)
                            ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white'
                            : 'text-gray-700 hover:text-blue-600 hover:bg-blue-50'
                        }`}
                      >
                        <span className="text-xl">{link.icon}</span>
                        {link.label}
                      </Link>
                    ))}
                  </div>
                </>
              )}

              {/* User Menu */}
              <div className="border-t border-gray-200 pt-4 mt-4">
                {user ? (
                  <div className="space-y-3">
                    <div className="px-4 py-2 bg-purple-50 rounded-xl border border-purple-200">
                      <div className="text-gray-800 font-semibold">👋 {user.name}</div>
                      <div className="text-sm text-purple-600 capitalize">{user.role}</div>
                    </div>
                    
                    {user.role === 'admin' ? (
                      <Link
                        to="/admin/dashboard"
                        onClick={() => setIsMenuOpen(false)}
                        className="flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl font-semibold"
                      >
                        <span className="text-xl">👑</span>
                        Admin Panel
                      </Link>
                    ) : (
                      <Link
                        to="/employee/dashboard"
                        onClick={() => setIsMenuOpen(false)}
                        className="flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-semibold"
                      >
                        <span className="text-xl">👤</span>
                        Employee Panel
                      </Link>
                    )}
                    
                    <button
                      onClick={() => {
                        logout()
                        setIsMenuOpen(false)
                      }}
                      className="flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-xl font-semibold w-full"
                    >
                      <span className="text-xl">🚪</span>
                      Logout
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <Link
                      to="/admin-login"
                      onClick={() => setIsMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-semibold"
                    >
                      <span className="text-xl">👑</span>
                      Admin Login
                    </Link>
                    <Link
                      to="/employee-login"
                      onClick={() => setIsMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-green-500 to-teal-500 text-white rounded-xl font-semibold"
                    >
                      <span className="text-xl">👤</span>
                      Employee Login
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}