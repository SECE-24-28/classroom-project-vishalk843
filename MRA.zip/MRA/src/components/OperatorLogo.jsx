export default function OperatorLogo({ operator, size = 'md' }) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-20 h-20'
  }

  const getOperatorLogo = (operator) => {
    switch(operator) {
      case 'Airtel':
        return (
          <div className={`${sizeClasses[size]} rounded-2xl airtel-gradient flex items-center justify-center shadow-lg`}>
            <div className="text-white font-bold text-lg">A</div>
          </div>
        )
      case 'Jio':
        return (
          <div className={`${sizeClasses[size]} rounded-2xl jio-gradient flex items-center justify-center shadow-lg`}>
            <div className="text-white font-bold text-lg">J</div>
          </div>
        )
      case 'Vi':
        return (
          <div className={`${sizeClasses[size]} rounded-2xl vi-gradient flex items-center justify-center shadow-lg`}>
            <div className="text-white font-bold text-lg">Vi</div>
          </div>
        )
      case 'BSNL':
        return (
          <div className={`${sizeClasses[size]} rounded-2xl bsnl-gradient flex items-center justify-center shadow-lg`}>
            <div className="text-white font-bold text-sm">BSNL</div>
          </div>
        )
      default:
        return (
          <div className={`${sizeClasses[size]} rounded-2xl bg-gradient-to-br from-gray-600 to-gray-700 flex items-center justify-center shadow-lg`}>
            <div className="text-white text-2xl">📱</div>
          </div>
        )
    }
  }

  return getOperatorLogo(operator)
}