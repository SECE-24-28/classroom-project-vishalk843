import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar'
import DataStatus from './components/DataStatus'
import ApiStatus from './components/ApiStatus'

// Pages
import Home from './pages/Home'
import Landing from './pages/Landing'
import About from './pages/About'
import Services from './pages/Services'
import Plans from './pages/Plans'
import Recharge from './pages/Recharge'
import Success from './pages/Success'
import History from './pages/History'
import Dashboard from './pages/Dashboard'

// Auth Pages
import AdminLogin from './pages/AdminLogin'
import EmployeeLogin from './pages/EmployeeLogin'

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard'
import ManagePlans from './pages/admin/ManagePlans'

// Employee Pages
import EmployeeDashboard from './pages/employee/EmployeeDashboard'

import { useAuth } from './context/AuthContext'

function Protected({ children, role }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/" replace />;
  if (role && user.role !== role) return <Navigate to="/" replace />;
  return children;
}

export default function App(){
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-white">
        <Navbar />
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Home />} />
          <Route path="/landing" element={<Landing />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/plans" element={<Plans />} />
          
          {/* Auth Routes */}
          <Route path="/admin-login" element={<AdminLogin />} />
          <Route path="/employee-login" element={<EmployeeLogin />} />

          {/* Protected Routes */}
          <Route path="/recharge/:id" element={<Recharge />} />
          <Route path="/success" element={<Success />} />
          <Route path="/history" element={<History />} />
          <Route path="/dashboard" element={<Dashboard />} />

          {/* Admin Routes */}
          <Route path="/admin/dashboard" element={
            <Protected role="admin"><AdminDashboard /></Protected>
          } />
          <Route path="/admin/create" element={
            <Protected role="admin"><ManagePlans /></Protected>
          } />
          <Route path="/admin/edit/:id" element={
            <Protected role="admin"><ManagePlans /></Protected>
          } />

          {/* Employee Routes */}
          <Route path="/employee/dashboard" element={
            <Protected role="employee"><EmployeeDashboard /></Protected>
          } />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        
        <DataStatus />
        <ApiStatus />
      </div>
    </BrowserRouter>
  )
}