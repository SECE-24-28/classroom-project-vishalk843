import axios from 'axios';

// MockAPI Configuration
// Replace with your actual MockAPI URL from https://mockapi.io
const ROOT = 'https://674b8b8671933a4e885439b8.mockapi.io/api';

// Set to false to use MockAPI, true to use localStorage fallback
// Currently using fallback - update ROOT URL and set to false when MockAPI is ready
const USE_FALLBACK = true;
const API = axios.create({ baseURL: ROOT, timeout: 10000 });

// Fallback storage functions
const getFromStorage = (key) => {
  try {
    return JSON.parse(localStorage.getItem(key) || '[]');
  } catch {
    return [];
  }
};

const saveToStorage = (key, data) => {
  localStorage.setItem(key, JSON.stringify(data));
};

const generateId = () => {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substr(2, 9);
  return `${timestamp}_${random}`;
};

// Plans resource with fallback
// Initialize sample data only once
const initializeSampleData = () => {
  const hasInitialized = localStorage.getItem('qt_initialized');
  if (!hasInitialized) {
    const samplePlans = [
      // Airtel Plans
      { id: '1', title: 'Airtel Starter', amount: 99, validity: '28 days', description: 'Unlimited calls + 1GB/day', operator: 'Airtel', category: 'Data', benefits: ['Unlimited Voice', '1GB/day', '100 SMS/day'] },
      { id: '2', title: 'Airtel Freedom', amount: 199, validity: '28 days', description: 'Unlimited calls + 2GB/day', operator: 'Airtel', category: 'Data', benefits: ['Unlimited Voice', '2GB/day', '100 SMS/day', 'Airtel Thanks'] },
      { id: '3', title: 'Airtel Infinity', amount: 399, validity: '84 days', description: 'Unlimited calls + 6GB/day', operator: 'Airtel', category: 'Data', benefits: ['Unlimited Voice', '6GB/day', '100 SMS/day', 'Disney+ Hotstar'] },
      
      // Jio Plans
      { id: '4', title: 'Jio Basic', amount: 129, validity: '28 days', description: 'Unlimited calls + 2GB/day', operator: 'Jio', category: 'Data', benefits: ['Unlimited Voice', '2GB/day', '100 SMS/day', 'JioApps'] },
      { id: '5', title: 'Jio Prime', amount: 249, validity: '28 days', description: 'Unlimited calls + 3GB/day', operator: 'Jio', category: 'Data', benefits: ['Unlimited Voice', '3GB/day', '100 SMS/day', 'Netflix Mobile', 'JioCinema'] },
      { id: '6', title: 'Jio Max', amount: 449, validity: '84 days', description: 'Unlimited calls + 4GB/day', operator: 'Jio', category: 'Data', benefits: ['Unlimited Voice', '4GB/day', '100 SMS/day', 'Netflix', 'Amazon Prime'] },
      
      // Vi (Vodafone Idea) Plans
      { id: '7', title: 'Vi Starter', amount: 109, validity: '28 days', description: 'Unlimited calls + 1.5GB/day', operator: 'Vi', category: 'Data', benefits: ['Unlimited Voice', '1.5GB/day', '100 SMS/day'] },
      { id: '8', title: 'Vi Hero', amount: 219, validity: '28 days', description: 'Unlimited calls + 2.5GB/day', operator: 'Vi', category: 'Data', benefits: ['Unlimited Voice', '2.5GB/day', '100 SMS/day', 'Vi Movies & TV'] },
      { id: '9', title: 'Vi Champion', amount: 379, validity: '56 days', description: 'Unlimited calls + 3GB/day', operator: 'Vi', category: 'Data', benefits: ['Unlimited Voice', '3GB/day', '100 SMS/day', 'Disney+ Hotstar'] },
      
      // BSNL Plans
      { id: '10', title: 'BSNL Value', amount: 87, validity: '28 days', description: 'Unlimited calls + 2GB/day', operator: 'BSNL', category: 'Data', benefits: ['Unlimited Voice', '2GB/day', '100 SMS/day'] },
      { id: '11', title: 'BSNL Super', amount: 197, validity: '70 days', description: 'Unlimited calls + 2GB/day', operator: 'BSNL', category: 'Data', benefits: ['Unlimited Voice', '2GB/day', '100 SMS/day'] },
      
      // Top-up Plans
      { id: '12', title: 'Data Booster 1GB', amount: 19, validity: '1 day', description: '1GB Extra Data', operator: 'All', category: 'Top-up', benefits: ['1GB Data'] },
      { id: '13', title: 'Data Booster 5GB', amount: 75, validity: '7 days', description: '5GB Extra Data', operator: 'All', category: 'Top-up', benefits: ['5GB Data'] },
      { id: '14', title: 'Talk Time ₹50', amount: 50, validity: 'As per base plan', description: 'Main Balance Top-up', operator: 'All', category: 'Top-up', benefits: ['₹50 Talk Time'] },
      { id: '15', title: 'Talk Time ₹100', amount: 100, validity: 'As per base plan', description: 'Main Balance Top-up', operator: 'All', category: 'Top-up', benefits: ['₹100 Talk Time'] }
    ];
    const sampleRecharges = [
      {
        id: '1',
        employeeId: 'emp1',
        employee: 'Employee One',
        planId: '1',
        mobile: '9876543210',
        amount: 99,
        status: 'success',
        date: new Date(Date.now() - 86400000).toISOString()
      },
      {
        id: '2',
        employeeId: 'admin1',
        employee: 'Admin User',
        planId: '2',
        mobile: '9876543211',
        amount: 199,
        status: 'success',
        date: new Date(Date.now() - 172800000).toISOString()
      }
    ];
    
    saveToStorage('qt_plans', samplePlans);
    saveToStorage('qt_recharges', sampleRecharges);
    localStorage.setItem('qt_initialized', 'true');
  }
};

export const getPlans = async () => {
  if (USE_FALLBACK) {
    initializeSampleData();
    const plans = getFromStorage('qt_plans');
    return { data: plans };
  }
  try {
    return await API.get('/plans');
  } catch (error) {
    console.warn('API failed, using fallback:', error.message);
    return getPlans(); // Recursive call with fallback
  }
};

export const addPlan = async (p) => {
  if (USE_FALLBACK) {
    const plans = getFromStorage('qt_plans');
    const newPlan = { ...p, id: generateId() };
    plans.push(newPlan);
    saveToStorage('qt_plans', plans);
    return { data: newPlan };
  }
  try {
    return await API.post('/plans', p);
  } catch (error) {
    console.warn('API failed, using fallback:', error.message);
    return addPlan(p); // Recursive call with fallback
  }
};

export const updatePlan = async (id, p) => {
  if (USE_FALLBACK) {
    const plans = getFromStorage('qt_plans');
    const index = plans.findIndex(plan => plan.id === id);
    if (index !== -1) {
      plans[index] = { ...plans[index], ...p };
      saveToStorage('qt_plans', plans);
      return { data: plans[index] };
    }
    throw new Error('Plan not found');
  }
  try {
    return await API.put(`/plans/${id}`, p);
  } catch (error) {
    console.warn('API failed, using fallback:', error.message);
    return updatePlan(id, p); // Recursive call with fallback
  }
};

export const deletePlan = async (id) => {
  if (USE_FALLBACK) {
    const plans = getFromStorage('qt_plans');
    const filtered = plans.filter(plan => plan.id !== id);
    saveToStorage('qt_plans', filtered);
    return { data: { id } };
  }
  try {
    return await API.delete(`/plans/${id}`);
  } catch (error) {
    console.warn('API failed, using fallback:', error.message);
    return deletePlan(id); // Recursive call with fallback
  }
};

// Recharges resource with fallback
export const getRecharges = async () => {
  if (USE_FALLBACK) {
    initializeSampleData();
    const recharges = getFromStorage('qt_recharges');
    return { data: recharges };
  }
  try {
    return await API.get('/recharges');
  } catch (error) {
    console.warn('API failed, using fallback:', error.message);
    return { data: getFromStorage('qt_recharges') };
  }
};

export const addRecharge = async (r) => {
  if (USE_FALLBACK) {
    const recharges = getFromStorage('qt_recharges');
    const newRecharge = { ...r, id: generateId() };
    recharges.push(newRecharge);
    saveToStorage('qt_recharges', recharges);
    return { data: newRecharge };
  }
  try {
    return await API.post('/recharges', r);
  } catch (error) {
    console.warn('API failed, using fallback:', error.message);
    const recharges = getFromStorage('qt_recharges');
    const newRecharge = { ...r, id: generateId() };
    recharges.push(newRecharge);
    saveToStorage('qt_recharges', recharges);
    return { data: newRecharge };
  }
};

export default API;
