// Debug utilities for development
export const clearAllData = () => {
  localStorage.removeItem('qt_plans');
  localStorage.removeItem('qt_recharges');
  localStorage.removeItem('qt_user');
  localStorage.removeItem('qt_initialized');
  console.log('All QuickTopUp data cleared');
  window.location.reload();
};

export const viewStoredData = () => {
  console.log('Plans:', JSON.parse(localStorage.getItem('qt_plans') || '[]'));
  console.log('Recharges:', JSON.parse(localStorage.getItem('qt_recharges') || '[]'));
  console.log('User:', JSON.parse(localStorage.getItem('qt_user') || 'null'));
  console.log('Initialized:', localStorage.getItem('qt_initialized'));
};

// Make functions available globally for debugging
window.qtDebug = {
  clearAllData,
  viewStoredData
};