# Quick MockAPI Setup

## 🚀 Fast Setup (5 minutes)

### 1. Create MockAPI Account
- Go to https://mockapi.io
- Click "Get started for free"
- Sign up with email or GitHub

### 2. Create New Project
- Click "New Project"
- Name it "QuickTopUp" or any name you prefer

### 3. Create Resources

#### Create "plans" resource:
1. Click "New Resource"
2. Name: `plans`
3. Add these fields:
   - `title` (Text)
   - `amount` (Number) 
   - `validity` (Text)
   - `description` (Text)
4. Click "Create"

#### Create "recharges" resource:
1. Click "New Resource" 
2. Name: `recharges`
3. Add these fields:
   - `employeeId` (Text)
   - `employee` (Text)
   - `planId` (Text)
   - `mobile` (Text)
   - `amount` (Number)
   - `status` (Text)
   - `date` (Text)
4. Click "Create"

### 4. Get Your API URL
- Copy the base URL from MockAPI dashboard
- It looks like: `https://[random-id].mockapi.io/api`

### 5. Update QuickTopUp
1. Open `src/api/api.js`
2. Replace this line:
   ```javascript
   const ROOT = 'https://674b8b8671933a4e885439b8.mockapi.io/api';
   ```
   With your URL:
   ```javascript
   const ROOT = 'https://[your-id].mockapi.io/api';
   ```
3. Change this line:
   ```javascript
   const USE_FALLBACK = true;
   ```
   To:
   ```javascript
   const USE_FALLBACK = false;
   ```

### 6. Test Connection
```bash
npm run dev
```

### 7. Add Sample Data (Optional)
Update the MockAPI URL in `setup-mockapi.js` and run:
```bash
npm run setup-mockapi
```

## ✅ Verification

After setup, you should see:
- 🌐 "Connected (MockAPI)" in top-right corner
- Plans persist after page refresh
- Data visible in MockAPI dashboard

## 🔄 Switch Back to Local Storage

If MockAPI isn't working, set `USE_FALLBACK = true` in `src/api/api.js`

## 📞 Need Help?

Common issues:
- **404 Error**: Check resource names are exactly `plans` and `recharges`
- **CORS Error**: MockAPI handles this automatically
- **Network Error**: Check internet connection and URL

The app works perfectly with localStorage fallback if you prefer offline storage!